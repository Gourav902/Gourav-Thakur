import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, Plugin } from 'vite';
import { createClient } from '@supabase/supabase-js';

const SUPABASE_PROJECT_ID = 'mvmpfjkawcgmjzsabuwz';
const SUPABASE_URL = `https://${SUPABASE_PROJECT_ID}.supabase.co`;
const SUPABASE_KEY = 'sb_secret_77YmRmjiONgJC1h3a5S3cg_4RBAHBr7';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});

const localBookings: any[] = [];

function supabaseApiPlugin(): Plugin {
  return {
    name: 'supabase-api-plugin',
    configureServer(server) {
      server.middlewares.use('/api/supabase-status', async (_req, res) => {
        res.setHeader('Content-Type', 'application/json');
        try {
          const { error } = await supabase.from('bookings').select('id').limit(1);
          if (error && error.code === 'PGRST205') {
            res.end(
              JSON.stringify({
                connected: true,
                projectId: SUPABASE_PROJECT_ID,
                url: SUPABASE_URL,
                tableExists: false,
                message: "Connected to Supabase. Table 'bookings' needs creation in SQL editor.",
                localBackupCount: localBookings.length,
              })
            );
            return;
          }
          res.end(
            JSON.stringify({
              connected: !error,
              projectId: SUPABASE_PROJECT_ID,
              url: SUPABASE_URL,
              tableExists: !error,
              message: !error
                ? "Connected to Supabase 'bookings' table successfully!"
                : error?.message,
              localBackupCount: localBookings.length,
            })
          );
        } catch (err: any) {
          res.end(
            JSON.stringify({
              connected: false,
              error: err.message,
              localBackupCount: localBookings.length,
            })
          );
        }
      });

      server.middlewares.use('/api/bookings', async (req, res) => {
        if (req.method === 'GET') {
          res.setHeader('Content-Type', 'application/json');
          try {
            const { data, error } = await supabase
              .from('bookings')
              .select('*')
              .order('created_at', { ascending: false });

            if (!error && data?.length) {
              res.end(JSON.stringify({ source: 'supabase', bookings: data, total: data.length }));
            } else {
              res.end(
                JSON.stringify({
                  source: 'local_backup',
                  bookings: localBookings,
                  total: localBookings.length,
                })
              );
            }
          } catch {
            res.end(
              JSON.stringify({
                source: 'local_backup',
                bookings: localBookings,
                total: localBookings.length,
              })
            );
          }
          return;
        }

        if (req.method === 'POST') {
          let body = '';
          req.on('data', (chunk) => {
            body += chunk;
          });
          req.on('end', async () => {
            res.setHeader('Content-Type', 'application/json');
            try {
              const data = JSON.parse(body);
              const orderId =
                data.orderId || `SC-${Math.floor(100000 + Math.random() * 900000)}`;
              const record = {
                order_id: orderId,
                full_name: data.fullName,
                phone: data.phone,
                address: data.address,
                city: data.city,
                state: data.state || '',
                pincode: data.pincode,
                bundle_id: data.bundleId,
                bundle_title: data.bundleTitle || '',
                bottles: data.bottles || 1,
                price: data.price,
                payment_method: data.paymentMethod || 'cod',
                status: 'confirmed',
                created_at: new Date().toISOString(),
              };

              const { data: dbData, error } = await supabase
                .from('bookings')
                .insert([record])
                .select();

              localBookings.unshift(record);

              res.statusCode = 201;
              res.end(
                JSON.stringify({
                  success: true,
                  orderId,
                  savedInSupabase: !error,
                  supabaseData: dbData,
                  record,
                })
              );
            } catch (e: any) {
              res.statusCode = 400;
              res.end(JSON.stringify({ error: e.message }));
            }
          });
          return;
        }
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), supabaseApiPlugin()],
    resolve: {
      alias: {
        '@': path.resolve('.'),
      },
    },
    server: {
      port: 3000,
      host: '0.0.0.0',
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
