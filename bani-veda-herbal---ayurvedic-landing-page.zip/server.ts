import express from 'express';
import { createServer as createViteServer } from 'vite';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

const SUPABASE_PROJECT_ID = process.env.SUPABASE_PROJECT_ID || 'mvmpfjkawcgmjzsabuwz';
const SUPABASE_URL = process.env.SUPABASE_URL || `https://${SUPABASE_PROJECT_ID}.supabase.co`;
const SUPABASE_KEY =
  process.env.SUPABASE_API_KEY ||
  process.env.SUPABASE_KEY ||
  'sb_secret_77YmRmjiONgJC1h3a5S3cg_4RBAHBr7';

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: {
    persistSession: false,
    autoRefreshToken: false,
  },
});

export interface BookingRecord {
  order_id: string;
  full_name: string;
  phone: string;
  address: string;
  city: string;
  state?: string;
  pincode: string;
  bundle_id: string;
  bundle_title?: string;
  bottles?: number;
  price: number;
  payment_method: string;
  status: string;
  created_at: string;
  saved_in_supabase: boolean;
}

// In-memory backup store so no customer order is ever lost
const localBookingsBackup: BookingRecord[] = [];

// API: Check Supabase connection & table health
app.get('/api/supabase-status', async (_req, res) => {
  try {
    const { data: _data, error } = await supabase.from('bookings').select('id').limit(1);

    if (error) {
      if (error.code === 'PGRST205') {
        return res.json({
          connected: true,
          projectId: SUPABASE_PROJECT_ID,
          url: SUPABASE_URL,
          tableExists: false,
          message:
            "Connected to Supabase successfully. The 'bookings' table is awaiting creation in SQL Editor.",
          localBackupCount: localBookingsBackup.length,
        });
      }
      return res.json({
        connected: false,
        projectId: SUPABASE_PROJECT_ID,
        url: SUPABASE_URL,
        error: error.message,
        tableExists: false,
        localBackupCount: localBookingsBackup.length,
      });
    }

    return res.json({
      connected: true,
      projectId: SUPABASE_PROJECT_ID,
      url: SUPABASE_URL,
      tableExists: true,
      message: "Connected to Supabase 'bookings' table successfully!",
      localBackupCount: localBookingsBackup.length,
    });
  } catch (err: any) {
    return res.status(500).json({
      connected: false,
      error: err.message,
      localBackupCount: localBookingsBackup.length,
    });
  }
});

// API: Submit booking to Supabase
app.post('/api/bookings', async (req, res) => {
  try {
    const {
      orderId,
      fullName,
      phone,
      address,
      city,
      state = '',
      pincode,
      bundleId,
      bundleTitle = '',
      bottles = 1,
      price,
      paymentMethod = 'cod',
    } = req.body;

    if (!fullName || !phone || !address || !pincode) {
      return res.status(400).json({ error: 'Missing required order fields' });
    }

    const newRecord: BookingRecord = {
      order_id: orderId || `SC-${Math.floor(100000 + Math.random() * 900000)}`,
      full_name: fullName,
      phone,
      address,
      city,
      state,
      pincode,
      bundle_id: bundleId,
      bundle_title: bundleTitle,
      bottles: Number(bottles) || 1,
      price: Number(price) || 0,
      payment_method: paymentMethod,
      status: 'confirmed',
      created_at: new Date().toISOString(),
      saved_in_supabase: false,
    };

    // Try saving to Supabase public.bookings table
    const { data, error } = await supabase
      .from('bookings')
      .insert([
        {
          order_id: newRecord.order_id,
          full_name: newRecord.full_name,
          phone: newRecord.phone,
          address: newRecord.address,
          city: newRecord.city,
          state: newRecord.state,
          pincode: newRecord.pincode,
          bundle_id: newRecord.bundle_id,
          bundle_title: newRecord.bundle_title,
          bottles: newRecord.bottles,
          price: newRecord.price,
          payment_method: newRecord.payment_method,
          status: newRecord.status,
        },
      ])
      .select();

    if (error) {
      console.warn('Supabase insert status:', error.message);
      newRecord.saved_in_supabase = false;
      localBookingsBackup.unshift(newRecord);

      return res.json({
        success: true,
        orderId: newRecord.order_id,
        savedInSupabase: false,
        warning:
          error.code === 'PGRST205'
            ? "Table 'bookings' needs to be created in Supabase SQL editor. Order backed up safely."
            : error.message,
        record: newRecord,
      });
    }

    newRecord.saved_in_supabase = true;
    localBookingsBackup.unshift(newRecord);

    return res.status(201).json({
      success: true,
      orderId: newRecord.order_id,
      savedInSupabase: true,
      supabaseData: data,
      record: newRecord,
    });
  } catch (err: any) {
    console.error('Server error saving booking:', err);
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
});

// API: List all bookings
app.get('/api/bookings', async (_req, res) => {
  try {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      return res.json({
        source: 'supabase',
        bookings: data,
        total: data.length,
      });
    }

    return res.json({
      source: 'local_backup',
      bookings: localBookingsBackup,
      total: localBookingsBackup.length,
      note: error ? error.message : undefined,
    });
  } catch (err: any) {
    return res.json({
      source: 'local_backup',
      bookings: localBookingsBackup,
      total: localBookingsBackup.length,
    });
  }
});

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Bani Veda Server with Supabase integration running on port ${PORT}`);
  });
}

startServer();
