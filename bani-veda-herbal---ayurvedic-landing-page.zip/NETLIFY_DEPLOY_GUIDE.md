# Netlify Deployment Guide for Bani Veda

Your project is fully configured for seamless deployment to Netlify!

---

## Method 1: Deploy with Git (Recommended)
1. Push your repository to **GitHub** (or GitLab / Bitbucket).
2. Go to [app.netlify.com](https://app.netlify.com) and click **"Add new site"** -> **"Import an existing project"**.
3. Select your repository.
4. Netlify will automatically detect `netlify.toml` with the correct settings:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
5. *(Optional)* In **Site configuration > Environment variables**, you can set:
   - `VITE_SUPABASE_URL`: `https://mvmpfjkawcgmjzsabuwz.supabase.co`
   - `VITE_SUPABASE_ANON_KEY`: `sb_secret_77YmRmjiONgJC1h3a5S3cg_4RBAHBr7`
6. Click **"Deploy site"**. Your site will be live on a `*.netlify.app` domain in seconds!

---

## Method 2: Deploy via Netlify CLI (Fastest)
From your terminal:
```bash
# 1. Build the production bundle
npm run build

# 2. Deploy directly to Netlify
npx netlify deploy --prod --dir=dist
```

---

## Method 3: Drag & Drop (Netlify Drop)
1. Run `npm run build` locally.
2. Open [app.netlify.com/drop](https://app.netlify.com/drop).
3. Drag and drop the generated `dist` folder directly into your browser window.

---

## Supabase Database Connection
- All orders placed on your live Netlify site will automatically be saved into your **Supabase** account:
  - **Project ID:** `mvmpfjkawcgmjzsabuwz`
  - **Table:** `public.bookings`
- If you haven't yet created the `bookings` table in Supabase, run the script in `/supabase_setup.sql` in your [Supabase SQL Editor](https://supabase.com/dashboard/project/mvmpfjkawcgmjzsabuwz/sql).
