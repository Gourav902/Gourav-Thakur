import React from 'react';
import { Language } from '../types';
import { CONTACT_INFO } from '../data/content';
import { DirectOrderForm } from './DirectOrderForm';
import { ShieldCheck, Truck, Sparkles, CheckCircle2, ArrowRight, PhoneCall, MessageCircle } from 'lucide-react';

interface HeroProps {
  lang: Language;
  onOpenOrder: () => void;
  onScrollToQuiz: () => void;
}

export const Hero: React.FC<HeroProps> = ({ lang, onOpenOrder, onScrollToQuiz }) => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#f3f7f4] via-[#f8faf8] to-white pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-[#e5ebe6]">
      {/* Subtle organic decorative background glows */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#d1fae5]/40 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-[#fef3c7]/30 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Value Proposition & Copy */}
          <div className="lg:col-span-7 space-y-6">
            {/* Clean unboxed metadata kicker */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-[#0d5440] uppercase tracking-wider">
              <span>100% Shuddh Ayurvedic</span>
              <span aria-hidden="true" className="text-[#a4c5b5]">·</span>
              <span>6-in-1 Powerful Herbs</span>
              <span aria-hidden="true" className="text-[#a4c5b5]">·</span>
              <span>Zero Side Effects</span>
            </div>

            {/* Display Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-[44px] font-extrabold text-[#0a2f24] leading-[1.18] tracking-tight text-balance">
              {lang === 'hi' ? (
                <>
                  प्राकृतिक रूप से ब्लड शुगर को रखें <span className="text-[#0e684d] underline decoration-[#f59e0b] decoration-4 underline-offset-4">संतुलित व नियंत्रित</span>
                </>
              ) : (
                <>
                  Keep Blood Sugar <span className="text-[#0e684d] underline decoration-[#f59e0b] decoration-4 underline-offset-4">Naturally Balanced</span> & Controlled
                </>
              )}
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-[#31483c] leading-relaxed max-w-2xl">
              {lang === 'hi'
                ? 'नीम, करेला, जामुन, मेथी, दालचीनी और गुड़मार का प्राचीन त्रिदोष-शामक सम्मिश्रण। पैंक्रियाज की बीटा-कोशिकाओं को सक्रिय कर भोजन के बाद अचानक शुगर स्पाइक्स को रोके और दिनभर भरपूर ऊर्जा दे।'
                : 'Ancient synergistic blend of Neem, Karela, Jamun, Methi, Dalchini, and Gurmar. Revitalizes pancreatic beta-cells, prevents post-meal sugar spikes, and restores sustained daily vitality.'}
            </p>

            {/* Core Botanical Pills - Unboxed elegant list */}
            <div className="p-3.5 bg-white/80 backdrop-blur-sm rounded-xl border border-[#dce6e0] shadow-xs">
              <p className="text-xs font-bold text-[#0d5440] uppercase tracking-wider mb-2">
                {lang === 'hi' ? '6 शक्तिशाली जड़ी-बूटियों का अर्क (Extracts):' : '6 Powerful Herbal Extracts:'}
              </p>
              <div className="flex flex-wrap items-center gap-y-1.5 gap-x-3 text-xs sm:text-sm font-semibold text-[#183529]">
                <span className="flex items-center gap-1 text-[#083c2e]">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#10b981]" />
                  {lang === 'hi' ? 'नीम (Neem)' : 'Neem'}
                </span>
                <span className="text-[#b9ccc1]">|</span>
                <span className="flex items-center gap-1 text-[#083c2e]">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#10b981]" />
                  {lang === 'hi' ? 'करेला (Karela)' : 'Karela'}
                </span>
                <span className="text-[#b9ccc1]">|</span>
                <span className="flex items-center gap-1 text-[#083c2e]">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#10b981]" />
                  {lang === 'hi' ? 'जामुन (Jamun)' : 'Jamun'}
                </span>
                <span className="text-[#b9ccc1]">|</span>
                <span className="flex items-center gap-1 text-[#083c2e]">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#10b981]" />
                  {lang === 'hi' ? 'मेथी (Methi)' : 'Methi'}
                </span>
                <span className="text-[#b9ccc1]">|</span>
                <span className="flex items-center gap-1 text-[#083c2e]">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#10b981]" />
                  {lang === 'hi' ? 'दालचीनी (Dalchini)' : 'Dalchini'}
                </span>
                <span className="text-[#b9ccc1]">|</span>
                <span className="flex items-center gap-1 text-[#083c2e]">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#10b981]" />
                  {lang === 'hi' ? 'गुड़मार (Gurmar)' : 'Gurmar'}
                </span>
              </div>
            </div>

            {/* Price Lockup and CTA Actions */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={() => {
                  const formEl = document.getElementById('quick-order-form');
                  if (formEl) {
                    formEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    const inputEl = formEl.querySelector('input');
                    if (inputEl) inputEl.focus();
                  } else {
                    onOpenOrder();
                  }
                }}
                className="group relative flex items-center justify-center gap-3 px-7 py-3.5 text-base font-bold text-white bg-[#083c2e] hover:bg-[#0c4e3c] rounded-xl shadow-md hover:shadow-lg transition-all active:scale-[0.99] cursor-pointer"
              >
                <span>{lang === 'hi' ? 'दवा का ऑर्डर फॉर्म भरें (COD)' : 'Fill Delivery Form (Free COD)'}</span>
                <ArrowRight className="w-4 h-4 text-[#f59e0b] group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onScrollToQuiz}
                className="flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-semibold text-[#083c2e] bg-white hover:bg-[#edf4f0] border border-[#d2dfd8] rounded-xl transition-colors shadow-2xs"
              >
                <Sparkles className="w-4 h-4 text-[#f59e0b]" />
                <span>{lang === 'hi' ? 'अपनी सही डोज़ जानें' : 'Check Your Recommended Dose'}</span>
              </button>
            </div>

            {/* Direct Phone / WhatsApp Quick Order Strip */}
            <div className="p-3 bg-[#eef7f2] rounded-xl border border-[#cbe3d5] flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#10b981] animate-pulse"></span>
                <span className="font-bold text-[#083c2e]">
                  {lang === 'hi'
                    ? 'सीधे फोन या WhatsApp पर ऑर्डर बुक करें:'
                    : 'Order directly via Phone or WhatsApp:'}
                </span>
                <span className="font-extrabold text-[#083c2e] text-sm tabular-nums tracking-wide">
                  {CONTACT_INFO.displayPhone}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={CONTACT_INFO.telUrl}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-[#083c2e] hover:bg-[#0c4e3c] text-white font-bold rounded-lg transition-colors shadow-2xs"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-[#f59e0b]" />
                  <span>{lang === 'hi' ? 'कॉल करें' : 'Call Now'}</span>
                </a>
                <a
                  href={CONTACT_INFO.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-[#25d366] hover:bg-[#1faa53] text-white font-bold rounded-lg transition-colors shadow-2xs"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
              </div>
            </div>

            {/* Trust Markers Bar */}
            <div className="grid grid-cols-3 gap-3 pt-4 border-t border-[#e2ece6] text-xs text-[#2b4438]">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#0d5440] shrink-0" />
                <span>
                  <strong className="block text-[#083c2e] font-semibold">{lang === 'hi' ? 'मुफ्त डिलीवरी' : 'Free Delivery'}</strong>
                  {lang === 'hi' ? 'सभी पिनकोड पर' : 'All Over India'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#0d5440] shrink-0" />
                <span>
                  <strong className="block text-[#083c2e] font-semibold">{lang === 'hi' ? 'कैश ऑन डिलीवरी' : 'Cash On Delivery'}</strong>
                  {lang === 'hi' ? 'हाथ में मिलने पर भुगतान' : 'Pay when received'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-[#10b981]/20 text-[#0d5440] flex items-center justify-center font-bold text-[10px] shrink-0">
                  ✓
                </div>
                <span>
                  <strong className="block text-[#083c2e] font-semibold">{lang === 'hi' ? '100% शाकाहारी' : '100% Vegetarian'}</strong>
                  {lang === 'hi' ? 'ग्लूटन व जिलेटिन फ्री' : 'Gluten & Gelatin Free'}
                </span>
              </div>
            </div>

          </div>

          {/* Right Column: Visual Product Showcase & Visible Direct Order Form */}
          <div className="lg:col-span-5 relative flex flex-col items-center w-full">
            {/* Subtle backdrop circle */}
            <div className="absolute inset-0 m-auto w-72 h-72 sm:w-88 sm:h-88 bg-gradient-to-tr from-[#093e30]/15 to-[#d1fae5]/40 rounded-full blur-2xl -z-10" />

            <div className="w-full max-w-[460px] space-y-4">
              
              {/* Product Bottle Showcase Card (Large, Clear & Premium) */}
              <div className="bg-gradient-to-b from-white via-[#f7faf8] to-[#edf5f1] p-4 sm:p-5 rounded-3xl border-2 border-[#10b981]/40 shadow-xl relative overflow-hidden group">
                {/* Floating ambient glow */}
                <div className="absolute top-0 right-0 w-44 h-44 bg-[#10b981]/10 rounded-full blur-2xl pointer-events-none" />

                {/* Top Badges */}
                <div className="flex items-center justify-between pb-3 border-b border-[#e2ece5] text-xs">
                  <span className="font-extrabold text-[#083c2e] flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#10b981] animate-pulse"></span>
                    {lang === 'hi' ? '100% शुद्ध आयुर्वेदिक औषधि' : '100% Authentic Ayurvedic'}
                  </span>
                  <span className="font-extrabold text-[#92400e] bg-[#fef3c7] border border-[#fde68a] px-2.5 py-0.5 rounded-full text-[11px]">
                    {lang === 'hi' ? '60 शुद्ध कैप्सूल्स' : '60 Pure Capsules'}
                  </span>
                </div>

                {/* Large, Beautiful & High-Resolution Medicine Showcase */}
                <div className="relative my-3.5 py-4 px-3 rounded-2xl bg-gradient-to-b from-[#f9fbf9] via-white to-[#edf5f0] border border-[#d6e3dc] flex flex-col items-center justify-center shadow-inner">
                  {/* Floating AYUSH seal */}
                  <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-2.5 py-1 rounded-lg border border-[#cde0d5] shadow-xs text-left">
                    <div className="text-[9px] font-bold text-[#5e776a] uppercase tracking-wider">
                      {lang === 'hi' ? 'प्रमाणित' : 'Certified'}
                    </div>
                    <div className="text-[11px] font-extrabold text-[#083c2e]">
                      AYUSH GMP
                    </div>
                  </div>

                  {/* Medicine Bottle Image - Prominent, Large & Crisp */}
                  <div className="relative w-full flex justify-center py-2">
                    <img
                      src="/assets/aistudio/image_e1bd28d3.png"
                      onError={(e) => {
                        const img = e.currentTarget as HTMLImageElement;
                        if (!img.src.includes('/public/')) {
                          img.src = '/public/assets/aistudio/image_e1bd28d3.png';
                        }
                      }}
                      alt="Bani Ayurveda 6-IN-1 Herbal Medicine Bottle"
                      referrerPolicy="no-referrer"
                      className="max-h-[250px] sm:max-h-[290px] w-auto object-contain drop-shadow-[0_16px_24px_rgba(8,60,46,0.22)] transition-transform duration-500 group-hover:scale-105"
                      loading="eager"
                    />
                  </div>

                  {/* Floating Price Pill */}
                  <div className="absolute bottom-3 right-3 bg-[#083c2e] text-white px-3 py-1.5 rounded-xl shadow-md border border-[#1b5c49]">
                    <div className="text-[9px] uppercase font-semibold text-[#fcd34d]">
                      {lang === 'hi' ? 'ऑफर मूल्य' : 'Offer Price'}
                    </div>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-base sm:text-lg font-black text-white tabular-nums">₹2,490</span>
                      <span className="text-[11px] text-[#9bb7ab] line-through tabular-nums">₹3,490</span>
                    </div>
                  </div>
                </div>

                {/* Product Title: Bani Ayurveda 6-IN-1 */}
                <div className="space-y-1 text-center pt-1">
                  <div className="text-xs uppercase font-extrabold text-[#059669] tracking-wider">
                    {lang === 'hi' ? '6-इन-1 हर्बल फॉर्मूलेशन' : '6-in-1 Ayurvedic Formula'}
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black text-[#083c2e] tracking-tight">
                    Bani Ayurveda 6-IN-1
                  </h3>
                  <p className="text-xs text-[#4b6657]">
                    {lang === 'hi'
                      ? 'नीम · करेला · जामुन · मेथी · दालचीनी · गुड़मार'
                      : 'Neem · Karela · Jamun · Methi · Dalchini · Gurmar'}
                  </p>
                  <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#083c2e] bg-[#eef7f2] px-3 py-1 rounded-full border border-[#cbe3d5] mt-1">
                    <Truck className="w-3.5 h-3.5 text-[#059669]" />
                    <span>{lang === 'hi' ? 'पूरे भारत में मुफ्त कैश ऑन डिलीवरी' : 'Free Cash On Delivery All Over India'}</span>
                  </div>
                </div>
              </div>

              {/* Readily Visible Order Form Fields (No Popup Needed) */}
              <DirectOrderForm lang={lang} initialBundleId="single" />

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
