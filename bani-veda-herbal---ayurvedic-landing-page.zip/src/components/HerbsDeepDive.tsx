import React, { useState } from 'react';
import { Language } from '../types';
import { HERBS_DATA } from '../data/content';
import { Leaf, Sparkles, CheckCircle2 } from 'lucide-react';

interface HerbsDeepDiveProps {
  lang: Language;
}

export const HerbsDeepDive: React.FC<HerbsDeepDiveProps> = ({ lang }) => {
  const [activeHerbId, setActiveHerbId] = useState<string>(HERBS_DATA[0].id);

  const activeHerb = HERBS_DATA.find((h) => h.id === activeHerbId) || HERBS_DATA[0];

  return (
    <section id="herbs" className="py-14 sm:py-20 bg-white border-b border-[#e5ece6]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#eef6f2] text-[#0d5440] text-xs font-bold rounded-md tracking-wider uppercase mb-3">
            <Leaf className="w-3.5 h-3.5 text-[#0d5440]" />
            <span>{lang === 'hi' ? '6 शक्तिशाली जड़ी-बूटियों का रहस्य' : 'The Science of 6 Sacred Herbs'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#093226] tracking-tight text-balance">
            {lang === 'hi'
              ? 'प्रत्येक कैप्सूल में 100% शुद्ध और मानकीकृत हर्बल अर्क'
              : '100% Pure, Standardized Extracts in Every Capsule'}
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#4a6356]">
            {lang === 'hi'
              ? 'साधारण चूर्ण या कच्ची जड़ी-बूटी की जगह, शुगर केयर में उच्च सांद्रता वाले मानकीकृत अर्क (Standardized Extracts) का सटीक आयुर्वेदिक अनुपात में उपयोग किया गया है।'
              : 'Unlike raw powders, Sugar Care utilizes high-potency standardized botanical extracts formulated in exact classical ratios.'}
          </p>
        </div>

        {/* Herb Selector Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 mb-8">
          {HERBS_DATA.map((herb) => {
            const isActive = herb.id === activeHerbId;
            return (
              <button
                key={herb.id}
                type="button"
                onClick={() => setActiveHerbId(herb.id)}
                className={`p-3 rounded-2xl border text-center transition-all ${
                  isActive
                    ? 'border-[#083c2e] bg-[#083c2e] text-white shadow-md scale-[1.02]'
                    : 'border-[#e0ebe4] bg-[#f9fbf9] text-[#2c4438] hover:border-[#b5cdbf]'
                }`}
              >
                <div className="text-xs sm:text-sm font-bold truncate">
                  {lang === 'hi' ? herb.nameHi.split(' ')[0] : herb.nameEn.split(' ')[0]}
                </div>
                <div className={`text-[10px] mt-0.5 truncate ${isActive ? 'text-[#f59e0b]' : 'text-[#627a6f]'}`}>
                  {herb.tag}
                </div>
              </button>
            );
          })}
        </div>

        {/* Active Herb Spotlight Card */}
        <div className="bg-[#f9fbf9] rounded-3xl border border-[#dce6e0] p-6 sm:p-10 shadow-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left detail info */}
            <div className="lg:col-span-8 space-y-5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-3 py-1 bg-[#083c2e] text-white text-xs font-bold rounded-lg tracking-wide">
                  {activeHerb.tag}
                </span>
                <span className="text-xs font-mono text-[#5b7367] italic">
                  Botanical: {activeHerb.botanicalName}
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-[#083c2e]">
                {lang === 'hi' ? activeHerb.nameHi : activeHerb.nameEn}
              </h3>

              <div className="p-4 bg-white rounded-2xl border border-[#e2ece5] space-y-2">
                <div className="text-xs font-bold text-[#b45309] uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  {lang === 'hi' ? 'सक्रिय बायोएक्टिव घटक (Key Active Principle):' : 'Key Active Bioactive:'}
                </div>
                <p className="text-sm font-semibold text-[#18362a]">
                  {activeHerb.keyActive}
                </p>
              </div>

              <p className="text-base text-[#2f463b] leading-relaxed">
                {activeHerb.benefit}
              </p>

              <div className="flex items-center gap-2 text-xs font-medium text-[#4b6659] pt-2 border-t border-[#e3ece7]">
                <CheckCircle2 className="w-4 h-4 text-[#10b981]" />
                <span>
                  <strong>{lang === 'hi' ? 'आयुर्वेदिक प्रभाव: ' : 'Ayurvedic Karma: '}</strong>
                  {activeHerb.ayurvedicAction}
                </span>
              </div>
            </div>

            {/* Right side botanical card badge */}
            <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-[#d6e3db] text-center space-y-4 shadow-sm">
              <div className="w-16 h-16 rounded-full bg-[#f0f6f2] text-[#083c2e] mx-auto flex items-center justify-center">
                <Leaf className="w-8 h-8 text-[#0d5440]" />
              </div>
              <div>
                <div className="text-xs text-[#6a8075] uppercase tracking-wider font-semibold">
                  {lang === 'hi' ? 'शुद्धता अनुपात' : 'Extraction Ratio'}
                </div>
                <div className="text-2xl font-black text-[#083c2e] tabular-nums mt-0.5">
                  10:1 Potency
                </div>
                <p className="text-xs text-[#526a5e] mt-1">
                  {lang === 'hi'
                    ? '10 किग्रा ताजी कच्ची बूटी से निकाला गया 1 किग्रा शुद्ध एक्सट्रेक्ट'
                    : '10kg of raw medicinal herb concentrated into 1kg pure standardized extract'}
                </p>
              </div>

              <div className="text-[11px] py-1.5 px-3 bg-[#f6f9f7] rounded-lg text-[#32493d] border border-[#e5eee8]">
                ✓ 100% Non-GMO & Heavy-Metal Free
              </div>
            </div>

          </div>
        </div>

        {/* 6 Herbs Summary Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
          <div className="p-4 bg-white rounded-2xl border border-[#e1eae4]">
            <span className="text-xs font-bold text-[#b45309] uppercase block mb-1">
              01. Sugar Blockers
            </span>
            <h4 className="text-base font-bold text-[#083c2e]">गुड़मार + जामुन गुठली</h4>
            <p className="text-xs text-[#4f675a] mt-1.5 leading-relaxed">
              {lang === 'hi'
                ? 'मुँह में मीठे का स्वाद मिटाते हैं और आंतों में चीनी व स्टार्च का पाचन धीमा कर ब्लडस्ट्रीम में ग्लूकोज नहीं आने देते।'
                : 'Neutralizes sweet receptors and prevents rapid starch-to-sugar conversion in the gut.'}
            </p>
          </div>

          <div className="p-4 bg-white rounded-2xl border border-[#e1eae4]">
            <span className="text-xs font-bold text-[#b45309] uppercase block mb-1">
              02. Plant Insulin Mimics
            </span>
            <h4 className="text-base font-bold text-[#083c2e]">करेला + दालचीनी</h4>
            <p className="text-xs text-[#4f675a] mt-1.5 leading-relaxed">
              {lang === 'hi'
                ? 'पॉलीपेप्टाइड-पी प्राकृतिक इंसुलिन जैसा काम करता है, जो सेल्स के दरवाजे खोलकर ग्लूकोज को ऊर्जा में बदलता है।'
                : 'Mimics natural insulin action, transporting circulating glucose directly into skeletal muscle cells.'}
            </p>
          </div>

          <div className="p-4 bg-white rounded-2xl border border-[#e1eae4]">
            <span className="text-xs font-bold text-[#b45309] uppercase block mb-1">
              03. Cellular Rejuvenators
            </span>
            <h4 className="text-base font-bold text-[#083c2e]">नीम + मेथी दाना</h4>
            <p className="text-xs text-[#4f675a] mt-1.5 leading-relaxed">
              {lang === 'hi'
                ? 'खून साफ करता है, पैंक्रियाज के तनाव को कम करता है और फाइबर द्वारा भोजन का ग्लाइसेमिक इंडेक्स घटाता है।'
                : 'Purifies blood toxins, reduces pancreatic stress, and modulates glycemic index via soluble fibers.'}
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
