import React, { useState, useEffect } from 'react';
import { Language } from '../types';
import { CONTACT_INFO } from '../data/content';
import { ShoppingBag, Truck, PhoneCall, MessageCircle } from 'lucide-react';

interface StickyBottomBarProps {
  lang: Language;
  onOpenOrder: () => void;
}

export const StickyBottomBar: React.FC<StickyBottomBarProps> = ({ lang, onOpenOrder }) => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show only after scrolling down 300px
      if (window.scrollY > 300) {
        setShow(true);
      } else {
        setShow(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!show) return null;

  return (
    <div className="fixed bottom-0 inset-x-0 z-40 bg-[#ffffff]/95 backdrop-blur-md border-t border-[#d8e4dd] py-2 px-3 sm:px-6 shadow-lg transition-transform duration-300">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-2 sm:gap-3 h-11">
        {/* Price & info */}
        <div className="flex items-center gap-2 sm:gap-3 text-xs shrink-0">
          <div>
            <span className="text-[10px] text-[#556e61] uppercase tracking-wider block font-semibold leading-none">
              {lang === 'hi' ? 'विशेष ऑफर' : 'Special Price'}
            </span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-base sm:text-lg font-extrabold text-[#083c2e] tabular-nums leading-none">
                ₹2,490
              </span>
              <span className="text-[11px] text-[#8ea498] line-through tabular-nums leading-none">
                ₹3,490
              </span>
            </div>
          </div>
          <span className="hidden sm:inline-flex items-center gap-1 text-[11px] text-[#059669] font-bold bg-[#eef7f2] px-2 py-0.5 rounded">
            <Truck className="w-3 h-3" />
            {lang === 'hi' ? 'फ्री कैश ऑन डिलीवरी' : 'Free Cash On Delivery'}
          </span>
        </div>

        {/* CTA Buttons */}
        <div className="flex items-center gap-2">
          {/* Quick Call Button */}
          <a
            href={CONTACT_INFO.telUrl}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-2 bg-[#ecfdf5] border border-[#a7f3d0] hover:bg-[#d1fae5] text-[#083c2e] text-xs font-bold rounded-lg transition-all"
            title="Call 9711293726"
          >
            <PhoneCall className="w-3.5 h-3.5 text-[#059669]" />
            <span className="hidden xs:inline">{CONTACT_INFO.displayPhone}</span>
            <span className="xs:hidden">{lang === 'hi' ? 'कॉल' : 'Call'}</span>
          </a>

          {/* Quick WhatsApp Button */}
          <a
            href={CONTACT_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:flex items-center gap-1.5 px-3 py-2 bg-[#25d366] hover:bg-[#1faa53] text-white text-xs font-bold rounded-lg transition-all"
            title="WhatsApp 9711293726"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>WhatsApp</span>
          </a>

          {/* Primary Order Button */}
          <button
            onClick={onOpenOrder}
            className="flex items-center justify-center gap-1.5 px-3.5 sm:px-6 py-2 bg-[#083c2e] hover:bg-[#0c4e3c] text-white text-xs sm:text-sm font-extrabold rounded-lg transition-all active:scale-[0.98] shadow-sm whitespace-nowrap"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-[#f59e0b]" />
            <span>{lang === 'hi' ? 'ऑर्डर करें (COD)' : 'Order Free COD'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
