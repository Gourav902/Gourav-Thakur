import React, { useState } from 'react';
import { Language } from '../types';
import { CONTACT_INFO } from '../data/content';
import { PhoneCall, MessageCircle, X } from 'lucide-react';

interface FloatingContactProps {
  lang: Language;
}

export const FloatingContact: React.FC<FloatingContactProps> = ({ lang }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-16 sm:bottom-16 right-4 z-40 flex flex-col items-end gap-2">
      {/* Expanded popover menu */}
      {isOpen && (
        <div className="bg-white rounded-2xl shadow-2xl border border-[#d6e3dc] p-4 w-72 mb-1 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <div className="flex items-center justify-between pb-2 border-b border-[#e6eee9] mb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#10b981] animate-pulse"></span>
              <span className="text-xs font-bold text-[#083c2e] uppercase tracking-wider">
                {lang === 'hi' ? 'कस्टमर सहायता व ऑर्डर' : 'Support & Quick Order'}
              </span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-[#698476] hover:text-[#083c2e] p-1 rounded-md transition-colors"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-[#3d5749] mb-3 leading-relaxed">
            {lang === 'hi'
              ? 'क्या आप कोई सवाल पूछना चाहते हैं या सीधे फोन पर ऑर्डर करना चाहते हैं?'
              : 'Have a question or want to place your order directly over phone?'}
          </p>

          <div className="space-y-2">
            {/* Call button */}
            <a
              href={CONTACT_INFO.telUrl}
              className="flex items-center justify-between gap-3 p-2.5 bg-[#083c2e] hover:bg-[#0c4e3c] text-white rounded-xl font-bold text-xs transition-colors shadow-sm"
            >
              <span className="flex items-center gap-2">
                <PhoneCall className="w-4 h-4 text-[#f59e0b]" />
                <span>{lang === 'hi' ? 'सीधे कॉल करें' : 'Call Now'}</span>
              </span>
              <span className="font-mono text-sm tracking-wide tabular-nums font-extrabold text-[#f59e0b]">
                {CONTACT_INFO.displayPhone}
              </span>
            </a>

            {/* WhatsApp button */}
            <a
              href={CONTACT_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between gap-3 p-2.5 bg-[#25d366] hover:bg-[#1faa53] text-white rounded-xl font-bold text-xs transition-colors shadow-sm"
            >
              <span className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp चैट</span>
              </span>
              <span className="text-[11px] font-medium bg-black/15 px-2 py-0.5 rounded">
                24x7 Active
              </span>
            </a>
          </div>

          <div className="mt-2.5 text-[10px] text-center text-[#748f81]">
            {lang === 'hi' ? 'मोबाइल नंबर: 9711293726' : 'Mobile No: 9711293726'}
          </div>
        </div>
      )}

      {/* Main floating trigger buttons */}
      <div className="flex items-center gap-2">
        {/* Quick dial button */}
        <a
          href={CONTACT_INFO.telUrl}
          className="flex items-center gap-1.5 px-3 py-2.5 bg-[#083c2e] hover:bg-[#0c4e3c] text-white text-xs font-bold rounded-full shadow-lg border border-[#1b5c49] transition-transform hover:scale-105 active:scale-95"
          title="Call 9711293726"
        >
          <PhoneCall className="w-4 h-4 text-[#f59e0b]" />
          <span className="hidden sm:inline font-mono">{CONTACT_INFO.displayPhone}</span>
        </a>

        {/* WhatsApp pill button */}
        <button
          onClick={() => setIsOpen((prev) => !prev)}
          className="flex items-center gap-2 px-3.5 py-2.5 bg-[#25d366] hover:bg-[#1faa53] text-white rounded-full shadow-xl transition-transform hover:scale-105 active:scale-95"
          title="WhatsApp Helpline: 9711293726"
          aria-label="WhatsApp Helpline 9711293726"
        >
          <MessageCircle className="w-5 h-5 fill-current" />
          <span className="text-xs font-extrabold hidden md:inline">
            WhatsApp
          </span>
        </button>
      </div>
    </div>
  );
};
