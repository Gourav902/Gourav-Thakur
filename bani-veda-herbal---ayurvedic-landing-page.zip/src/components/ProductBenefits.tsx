import React from 'react';
import { Language } from '../types';
import { COMPARISON_ROWS } from '../data/content';
import { ShieldCheck, Zap, HeartPulse, RefreshCw, Check, X, Minus } from 'lucide-react';

interface ProductBenefitsProps {
  lang: Language;
}

export const ProductBenefits: React.FC<ProductBenefitsProps> = ({ lang }) => {
  return (
    <section id="benefits" className="py-14 sm:py-20 bg-[#f8faf8] border-b border-[#e2ebe5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#e3ede6] text-[#0d5440] text-xs font-bold rounded-md tracking-wider uppercase mb-3">
            <HeartPulse className="w-3.5 h-3.5 text-[#0d5440]" />
            <span>{lang === 'hi' ? 'आयुर्वेदिक कार्यप्रणाली' : 'Holistic Ayurvedic Mechanism'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#093226] tracking-tight text-balance">
            {lang === 'hi'
              ? 'सिर्फ शुगर दबाना नहीं, जड़ से मेटाबॉलिज्म को सुधारना'
              : 'Beyond Temporary Suppression: Root Cause Metabolic Balance'}
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#465f52]">
            {lang === 'hi'
              ? 'अधिकांश दवाइयां सिर्फ रक्त में मौजूद शुगर को दबाने का काम करती हैं। शुगर केयर शरीर की स्वयं इंसुलिन बनाने और उपयोग करने की प्राकृतिक क्षमता को पुनर्जीवित करता है।'
              : 'Conventional supplements merely mask sugar spikes temporarily. Sugar Care nourishes the cellular machinery responsible for insulin synthesis and glucose metabolism.'}
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          
          <div className="p-6 bg-white rounded-3xl border border-[#dce6df] shadow-2xs hover:border-[#b0c8ba] transition-all">
            <div className="w-12 h-12 rounded-2xl bg-[#ecfdf5] text-[#059669] flex items-center justify-center mb-4">
              <RefreshCw className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-[#083c2e] mb-2">
              {lang === 'hi' ? 'पैंक्रियाज बीटा-सेल पोषण' : 'Beta-Cell Regeneration'}
            </h3>
            <p className="text-xs sm:text-sm text-[#4f685b] leading-relaxed">
              {lang === 'hi'
                ? 'नीम और गुड़मार के सक्रिय एंजाइम अग्न्याशय (Pancreas) की थकी हुई कोशिकाओं को डिटॉक्स कर प्राकृतिक इंसुलिन स्राव को बढ़ाते हैं।'
                : 'Targeted polyphenols nourish sluggish pancreatic islet beta-cells, restoring the body’s endogenous insulin response.'}
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl border border-[#dce6df] shadow-2xs hover:border-[#b0c8ba] transition-all">
            <div className="w-12 h-12 rounded-2xl bg-[#fef3c7] text-[#d97706] flex items-center justify-center mb-4">
              <Zap className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-[#083c2e] mb-2">
              {lang === 'hi' ? 'आलस व कमजोरी से मुक्ति' : 'Sustained Cellular Vitality'}
            </h3>
            <p className="text-xs sm:text-sm text-[#4f685b] leading-relaxed">
              {lang === 'hi'
                ? 'जब रक्त शर्करा सीधे मांसपेशियों में ईंधन बनती है, तो दोपहर की तेज सुस्ती खत्म होती है और दिनभर भरपूर ऊर्जा बनी रहती है।'
                : 'Converts circulating glucose into real cellular glycogen, eliminating sudden post-meal brain fog and midday crashes.'}
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl border border-[#dce6df] shadow-2xs hover:border-[#b0c8ba] transition-all">
            <div className="w-12 h-12 rounded-2xl bg-[#eff6ff] text-[#2563eb] flex items-center justify-center mb-4">
              <HeartPulse className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-[#083c2e] mb-2">
              {lang === 'hi' ? 'तलवों की जलन व झनझनाहट' : 'Nerve & Peripheral Comfort'}
            </h3>
            <p className="text-xs sm:text-sm text-[#4f685b] leading-relaxed">
              {lang === 'hi'
                ? 'माइक्रो-वैस्कुलर रक्त संचार में सुधार होने से पैरों और हाथों के नसों में होने वाली चुभन, जलन और सुन्नता में आराम मिलता है।'
                : 'Boosts micro-capillary circulation, easing neuropathic tingling, foot burning, and nocturnal muscle cramps.'}
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl border border-[#dce6df] shadow-2xs hover:border-[#b0c8ba] transition-all">
            <div className="w-12 h-12 rounded-2xl bg-[#faf5ff] text-[#7c3aed] flex items-center justify-center mb-4">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-[#083c2e] mb-2">
              {lang === 'hi' ? 'बार-बार पेशाब व प्यास पर रोक' : 'Fluid & Glycemic Balance'}
            </h3>
            <p className="text-xs sm:text-sm text-[#4f685b] leading-relaxed">
              {lang === 'hi'
                ? 'जामुन गुठली का कसैला रस (Astringent Rasa) किडनी पर शुगर के तनाव को घटाता है, जिससे रात में बार-बार उठना नहीं पड़ता।'
                : 'Jamun’s natural astringent bio-actives relieve excessive renal osmotic pressure, reducing frequent nocturnal urination.'}
            </p>
          </div>

        </div>

        {/* Comparison Table Section */}
        <div className="bg-white rounded-3xl border border-[#d9e4dd] p-6 sm:p-8 shadow-sm">
          <div className="text-center max-w-xl mx-auto mb-8">
            <h3 className="text-xl sm:text-2xl font-extrabold text-[#083c2e]">
              {lang === 'hi'
                ? 'शुगर केयर 6-इन-1 बनाम साधारण बाजारू चूर्ण या केमिकल'
                : 'Sugar Care 6-in-1 vs Raw Powders & Harsh Synthetics'}
            </h3>
            <p className="text-xs sm:text-sm text-[#5a7266] mt-1.5">
              {lang === 'hi'
                ? 'जानें कि आधुनिक मानकीकृत आयुर्वेदिक कैप्सूल क्यों कहीं बेहतर हैं'
                : 'Why modern standardized herbal capsules outperform obsolete dusty concoctions'}
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-[#e2ece5]">
                  <th className="py-3 px-4 font-bold text-[#445d51] w-1/4">
                    {lang === 'hi' ? 'मापदंड (Parameters)' : 'Key Attribute'}
                  </th>
                  <th className="py-3 px-4 font-extrabold text-[#083c2e] bg-[#f0f7f3] rounded-t-xl w-1/3">
                    <div className="flex items-center gap-1.5 text-sm sm:text-base">
                      <span className="w-2 h-2 rounded-full bg-[#10b981]"></span>
                      Sugar Care (6 in 1)
                    </div>
                  </th>
                  <th className="py-3 px-4 font-semibold text-[#667a70] w-1/5">
                    {lang === 'hi' ? 'साधारण कच्चा चूर्ण' : 'Ordinary Raw Powders'}
                  </th>
                  <th className="py-3 px-4 font-semibold text-[#667a70] w-1/5">
                    {lang === 'hi' ? 'सिंथेटिक केमिकल्स' : 'Harsh Synthetics'}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#eaf0ec]">
                {COMPARISON_ROWS.map((row, idx) => (
                  <tr key={idx} className="hover:bg-[#fafcfa]">
                    <td className="py-4 px-4 font-bold text-[#1a372a]">
                      {lang === 'hi' ? row.parameterHi : row.parameterEn}
                    </td>
                    <td className="py-4 px-4 font-semibold text-[#083c2e] bg-[#f0f7f3]/60">
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-[#10b981] shrink-0" />
                        <span>{row.sugarCare}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-[#667a70]">
                      <div className="flex items-center gap-1.5">
                        <Minus className="w-3.5 h-3.5 text-[#f59e0b] shrink-0" />
                        <span>{row.marketPowder}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-[#667a70]">
                      <div className="flex items-center gap-1.5">
                        <X className="w-3.5 h-3.5 text-[#ef4444] shrink-0" />
                        <span>{row.chemicals}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </section>
  );
};
