import React from 'react';
import { Language } from '../types';
import { CONTACT_INFO } from '../data/content';
import { PhoneCall, ShieldCheck, Mail, MessageCircle, Database, FileSpreadsheet } from 'lucide-react';

interface FooterProps {
  lang: Language;
  onOpenDbAdmin?: () => void;
  onOpenSheets?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ lang, onOpenDbAdmin, onOpenSheets }) => {
  return (
    <footer className="bg-[#051f18] text-[#93b3a4] pt-12 pb-16 border-t border-[#0d3b2e] text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-[#0f4435]">
          
          {/* Brand info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2 text-white font-bold text-xl tracking-tight">
              <span className="w-2.5 h-2.5 rounded-full bg-[#10b981]"></span>
              <span>BANI VEDA AYURVEDA</span>
            </div>
            <p className="text-[#a8c9b9] max-w-md leading-relaxed">
              {lang === 'hi'
                ? 'शुगर केयर हर्बल कैप्सूल 6-इन-1 (नीम, करेला, जामुन, मेथी, दालचीनी, गुड़मार) शुद्ध प्राकृतिक तत्वों से निर्मित आयुर्वेदिक प्रोप्रायटरी औषधि है जो प्राकृतिक रूप से रक्त शर्करा के संतुलन में सहायता करती है।'
                : 'Sugar Care Herbal Capsule 6-in-1 is an authentic Ayurvedic proprietary dietary supplement manufactured with standardized botanical extracts to support healthy glycemic metabolism.'}
            </p>
            <div className="flex items-center gap-3 pt-2 text-[#bde0cf]">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-[#10b981]" />
                GMP Certified Facility
              </span>
              <span>·</span>
              <span>100% Ayurvedic Formula</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-2.5">
            <h4 className="text-white font-bold uppercase tracking-wider text-xs">
              {lang === 'hi' ? 'महत्वपूर्ण लिंक' : 'Quick Links'}
            </h4>
            <ul className="space-y-1.5 text-[#98b7a8]">
              <li><a href="#herbs" className="hover:text-white transition-colors">{lang === 'hi' ? '6 जड़ी-बूटियां' : '6 Key Herbs'}</a></li>
              <li><a href="#benefits" className="hover:text-white transition-colors">{lang === 'hi' ? 'आयुर्वेदिक लाभ' : 'Clinical Benefits'}</a></li>
              <li><a href="#calculator" className="hover:text-white transition-colors">{lang === 'hi' ? 'डोज़ कैलकुलेटर' : 'Dosage Check'}</a></li>
              <li><a href="#bundles" className="hover:text-white transition-colors">{lang === 'hi' ? 'पैकेज व मूल्य' : 'Pricing Packs'}</a></li>
              <li><a href="#faqs" className="hover:text-white transition-colors">{lang === 'hi' ? 'सवाल-जवाब' : 'FAQs'}</a></li>
            </ul>
          </div>

          {/* Contact Support */}
          <div className="space-y-2.5">
            <h4 className="text-white font-bold uppercase tracking-wider text-xs">
              {lang === 'hi' ? 'कस्टमर केयर व ऑर्डर हेल्पलाइन' : 'Customer Care & Order Helpline'}
            </h4>
            <div className="space-y-2 text-[#98b7a8]">
              <a
                href={CONTACT_INFO.telUrl}
                className="flex items-center gap-2 hover:text-white transition-colors group"
                title="Direct Phone Call"
              >
                <PhoneCall className="w-4 h-4 text-[#f59e0b] shrink-0 group-hover:scale-110 transition-transform" />
                <span className="tabular-nums font-mono text-white font-bold text-sm tracking-wide">
                  {CONTACT_INFO.displayPhone}
                </span>
                <span className="text-[10px] bg-[#0e4b39] text-[#6ee7b7] px-1.5 py-0.5 rounded font-semibold">
                  {lang === 'hi' ? 'कॉल' : 'Call'}
                </span>
              </a>

              <a
                href={CONTACT_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-[#4ade80] hover:text-white transition-colors group"
                title="WhatsApp Message"
              >
                <MessageCircle className="w-4 h-4 text-[#4ade80] shrink-0 group-hover:scale-110 transition-transform" />
                <span className="font-semibold text-xs">
                  {lang === 'hi' ? 'WhatsApp पर चैट करें' : 'Chat on WhatsApp'}: {CONTACT_INFO.phone}
                </span>
              </a>

              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#f59e0b] shrink-0" />
                <a href={`mailto:${CONTACT_INFO.email}`} className="hover:text-white transition-colors">
                  {CONTACT_INFO.email}
                </a>
              </div>
              <p className="text-[11px] text-[#7d9b8d] pt-1">
                {lang === 'hi' ? CONTACT_INFO.hoursHi : CONTACT_INFO.hoursEn}
              </p>
            </div>
          </div>

        </div>

        {/* Legal Disclaimer & Copyright */}
        <div className="pt-6 text-[11px] text-[#6d8a7c] space-y-3">
          <p className="leading-relaxed">
            {lang === 'hi'
              ? 'अस्वीकरण (Disclaimer): यह उत्पाद किसी भी बीमारी के निदान, उपचार या रोकथाम के लिए नहीं है। परिणाम व्यक्ति के आहार, जीवनशैली और शारीरिक प्रकृति (Prakriti) के अनुसार भिन्न हो सकते हैं। यदि आप गर्भवती हैं या गंभीर चिकित्सीय स्थिति में हैं, तो उपयोग से पूर्व अपने चिकित्सक से परामर्श लें।'
              : 'Disclaimer: This product is an Ayurvedic dietary supplement formulated to support healthy metabolic balance. It is not intended to diagnose, treat, or cure any disease. Results may vary depending on individual diet, lifestyle, and Prakriti. Consult your physician if pregnant or under medical supervision.'}
          </p>
          <div className="flex flex-wrap items-center justify-between gap-3 text-[#7f9e8f] pt-2 border-t border-[#0b3328]">
            <p>© {new Date().getFullYear()} Bani Veda Herbal Ayurveda. All rights reserved.</p>
            <div className="flex flex-wrap items-center gap-4">
              {onOpenDbAdmin && (
                <button
                  type="button"
                  onClick={onOpenDbAdmin}
                  className="inline-flex items-center gap-1.5 text-[#34d399] hover:text-[#6ee7b7] transition-colors font-medium cursor-pointer"
                  title="View Supabase Bookings & Connection"
                >
                  <Database className="w-3 h-3 text-[#34d399]" />
                  <span>Supabase DB</span>
                </button>
              )}
              {onOpenSheets && (
                <button
                  type="button"
                  onClick={onOpenSheets}
                  className="inline-flex items-center gap-1.5 text-[#34d399] hover:text-[#6ee7b7] transition-colors font-medium cursor-pointer"
                  title="Google Sheets Customer Orders Sync"
                >
                  <FileSpreadsheet className="w-3 h-3 text-[#34d399]" />
                  <span>Google Sheets Sync</span>
                </button>
              )}
              <span>Privacy Policy</span>
              <span>·</span>
              <span>Terms of Service</span>
              <span>·</span>
              <span>Shipping & Return Policy</span>
            </div>
          </div>
        </div>

      </div>
    </footer>
  );
};
