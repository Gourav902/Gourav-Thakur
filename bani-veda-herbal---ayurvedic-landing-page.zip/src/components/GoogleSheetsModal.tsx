import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import {
  initGoogleAuth,
  signInWithGoogleAuth,
  signOutGoogleAuth,
  getGoogleAccessToken,
} from '../lib/firebase';
import {
  getOrCreateOrdersSheet,
  getSavedSheetConfig,
  syncBatchOrdersToGoogleSheet,
  SheetConfig,
} from '../services/googleSheetsService';
import { getAllBookings } from '../services/bookingService';
import {
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  RefreshCw,
  X,
  UploadCloud,
  Check,
  LogOut,
} from 'lucide-react';

interface GoogleSheetsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GoogleSheetsModal: React.FC<GoogleSheetsModalProps> = ({ isOpen, onClose }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [sheetConfig, setSheetConfig] = useState<SheetConfig | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    // Load local config
    const saved = getSavedSheetConfig();
    if (saved) setSheetConfig(saved);

    const unsub = initGoogleAuth(
      (currentUser, accessToken) => {
        setUser(currentUser);
        setToken(accessToken);
      },
      () => {
        setUser(null);
        setToken(null);
      }
    );

    return () => unsub();
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSignIn = async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await signInWithGoogleAuth();
      setUser(res.user);
      setToken(res.accessToken);

      // Automatically find or create sheet on first sign-in
      const sheet = await getOrCreateOrdersSheet();
      setSheetConfig(sheet);
    } catch (err: any) {
      console.error('Google Sign-in failed:', err);
      setErrorMsg(err.message || 'Google Sign-in failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOut = async () => {
    await signOutGoogleAuth();
    setUser(null);
    setToken(null);
  };

  const handleConnectSheet = async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const sheet = await getOrCreateOrdersSheet();
      setSheetConfig(sheet);
      setSyncStatus('Sheet connected successfully!');
      setTimeout(() => setSyncStatus(null), 3000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to connect sheet');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSyncOrders = async () => {
    if (!sheetConfig) return;
    setIsLoading(true);
    setErrorMsg(null);
    setSyncStatus('Fetching bookings and updating Google Sheet...');
    try {
      const bookings = await getAllBookings();
      if (!bookings || bookings.length === 0) {
        setSyncStatus('No bookings to sync yet. Make a test order on the site!');
        setIsLoading(false);
        return;
      }

      const res = await syncBatchOrdersToGoogleSheet(sheetConfig.spreadsheetId, bookings);
      setSyncStatus(`Successfully synced ${res.added} orders into Google Sheet!`);
      setTimeout(() => setSyncStatus(null), 5000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to sync orders');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto bg-white rounded-3xl shadow-2xl border border-[#d6e2dc]">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between p-5 bg-[#083c2e] text-white rounded-t-3xl border-b border-[#145a46]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#10b981]/20 flex items-center justify-center text-[#10b981]">
              <FileSpreadsheet className="w-6 h-6 text-[#34d399]" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold">Google Sheets Integration</h3>
              <p className="text-xs text-[#a2d4c3]">Auto-sync all customer bookings to Google Sheets</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 text-white/80 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-6">
          {errorMsg && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {syncStatus && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{syncStatus}</span>
            </div>
          )}

          {/* User Auth Section */}
          <div className="p-4 bg-[#f8faf8] rounded-2xl border border-[#dce6df] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-[#083c2e]">
                Google Account Connection
              </span>
              {user ? (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#ecfdf5] text-[#059669] border border-[#a7f3d0]">
                  <Check className="w-3.5 h-3.5" />
                  Connected
                </span>
              ) : (
                <span className="text-xs text-[#718b7d]">Not signed in</span>
              )}
            </div>

            {user ? (
              <div className="flex items-center justify-between flex-wrap gap-3 pt-1">
                <div className="flex items-center gap-3">
                  {user.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt={user.displayName || 'User'}
                      className="w-10 h-10 rounded-full border border-[#cbdad2]"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-[#083c2e] text-white flex items-center justify-center font-bold text-sm">
                      {user.displayName?.[0] || 'U'}
                    </div>
                  )}
                  <div>
                    <div className="font-bold text-xs sm:text-sm text-[#083c2e]">
                      {user.displayName || 'Google Account'}
                    </div>
                    <div className="text-xs text-[#627d70]">{user.email}</div>
                  </div>
                </div>

                <button
                  onClick={handleSignOut}
                  className="inline-flex items-center gap-1.5 text-xs text-[#c2410c] hover:text-[#9a3412] font-semibold px-2.5 py-1.5 rounded-lg border border-[#fed7aa] bg-[#fffaf5] hover:bg-[#ffedd5] transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            ) : (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleSignIn}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-3 py-3 px-4 bg-white hover:bg-[#f3f4f6] text-[#374151] border border-[#d1d5db] font-semibold text-xs sm:text-sm rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 48 48">
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                  </svg>
                  <span>Sign in with Google to Connect Sheets</span>
                </button>
              </div>
            )}
          </div>

          {/* Connected Spreadsheet Section */}
          <div className="p-4 bg-[#f8faf8] rounded-2xl border border-[#dce6df] space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-[#083c2e]">
                Connected Google Sheet
              </span>
              {sheetConfig ? (
                <span className="text-xs font-bold text-[#059669] flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#10b981]"></span>
                  Active Sheet
                </span>
              ) : (
                <span className="text-xs text-[#718b7d]">None connected</span>
              )}
            </div>

            {sheetConfig ? (
              <div className="space-y-3">
                <div className="p-3 bg-white rounded-xl border border-[#e2ece6] flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <div className="font-bold text-xs sm:text-sm text-[#083c2e]">
                      {sheetConfig.spreadsheetTitle}
                    </div>
                    <div className="text-[11px] text-[#637d71] font-mono truncate max-w-xs">
                      ID: {sheetConfig.spreadsheetId}
                    </div>
                  </div>
                  <a
                    href={sheetConfig.spreadsheetUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#083c2e] hover:bg-[#0c4e3c] text-white text-xs font-bold rounded-lg shadow-2xs transition-colors"
                  >
                    <span>Open in Google Sheets</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleSyncOrders}
                    disabled={isLoading}
                    className="flex-1 py-2.5 px-4 bg-[#10b981] hover:bg-[#059669] text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <UploadCloud className="w-4 h-4" />
                    <span>Sync All Orders to Sheet</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleConnectSheet}
                    disabled={isLoading}
                    className="py-2.5 px-3 bg-white hover:bg-[#edf5f0] text-[#083c2e] border border-[#d2ded6] font-bold text-xs rounded-xl transition-colors"
                    title="Reconnect or refresh sheet"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-4 space-y-3">
                <p className="text-xs text-[#526b5e]">
                  Connect your Google account to automatically create and sync a Google Sheet named{' '}
                  <strong>"Bani Ayurveda - Customer Orders"</strong> with columns for Customer Name, Mobile, Address, Pincode, Pack, Price, and Status.
                </p>
                <button
                  type="button"
                  onClick={handleConnectSheet}
                  disabled={isLoading}
                  className="py-2.5 px-4 bg-[#083c2e] hover:bg-[#0c4e3c] text-white font-bold text-xs rounded-xl shadow-sm transition-colors cursor-pointer"
                >
                  Create & Connect Orders Sheet
                </button>
              </div>
            )}
          </div>

          {/* Features note */}
          <div className="p-3 bg-[#eef7f2] rounded-xl border border-[#cfe5d8] text-xs text-[#28493a] space-y-1.5">
            <div className="font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#059669]" />
              <span>Real-Time Automatic Sync</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              When Google Sheets is connected, every new customer order submitted on the site is automatically added as a new row in your spreadsheet in real time, so your fulfillment team can dispatch parcels without manual data entry.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
