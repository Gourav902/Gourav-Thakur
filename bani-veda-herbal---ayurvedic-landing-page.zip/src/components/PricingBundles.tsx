import React from 'react';
import { Language, PricingBundle } from '../types';
import { PRICING_BUNDLES, CONTACT_INFO } from '../data/content';
import { Check, ShieldCheck, Truck, Sparkles, ShoppingBag, PhoneCall, MessageCircle } from 'lucide-react';

interface PricingBundlesProps {
  lang: Language;
  onSelectBundle: (bundleId: string) => void;
}

export const PricingBundles: React.FC<PricingBundlesProps> = ({ lang, onSelectBundle }) => {
  return (
    <section id="bundles" className="py-14 sm:py-20 bg-gradient-to-b from-[#f3f7f4] to-white border-b border-[#e1eae3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#e4efe8] text-[#0d5440] text-xs font-bold rounded-md tracking-wider uppercase mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#0d5440]" />
            <span>{lang === 'hi' ? 'सीमित समय का रियायती मूल्य' : 'Limited-Time Direct Manufacturer Pricing'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#093226] tracking-tight text-balance">
            {lang === 'hi'
              ? 'अपना पैकेज चुनें - पूरे भारत में फ्री कैश ऑन डिलीवरी (COD)'
              : 'Choose Your Treatment Course - Free Cash on Delivery Nationwide'}
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#476254]">
            {lang === 'hi'
              ? 'कोई ऑनलाइन अग्रिम भुगतान आवश्यक नहीं है। जब कूरियर आपके घर पहुँचे, तभी नकद पैसे दें।'
              : 'No online payment required. Inspect parcel upon delivery and pay cash at your doorstep.'}
          </p>
        </div>

        {/* 3 Pricing Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {PRICING_BUNDLES.map((bundle: PricingBundle) => {
            const isPopular = bundle.popular;
            return (
              <div
                key={bundle.id}
                className={`relative rounded-3xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 ${
                  isPopular
                    ? 'bg-gradient-to-b from-[#083c2e] to-[#05261d] text-white shadow-2xl border-2 border-[#155a46] lg:-translate-y-3'
                    : 'bg-white text-[#193327] border border-[#dce6df] shadow-sm hover:border-[#b4cec0]'
                }`}
              >
                {/* Popular or Best Value Badge */}
                {bundle.badge && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                    <span
                      className={`text-xs font-extrabold px-4 py-1 rounded-full uppercase tracking-wider shadow-md whitespace-nowrap ${
                        isPopular
                          ? 'bg-[#f59e0b] text-[#14120f]'
                          : 'bg-[#0d5440] text-white'
                      }`}
                    >
                      {bundle.badge}
                    </span>
                  </div>
                )}

                <div>
                  {/* Title & Duration */}
                  <div className="text-center pb-6 border-b border-current/15">
                    <h3 className="text-xl sm:text-2xl font-extrabold">
                      {lang === 'hi' ? bundle.titleHi : bundle.titleEn}
                    </h3>
                    <p className={`text-xs mt-1 ${isPopular ? 'text-[#b3dfcc]' : 'text-[#647c70]'}`}>
                      {bundle.bottles} {lang === 'hi' ? 'बॉटल' : 'Bottle(s)'} ({bundle.capsuleCount} {lang === 'hi' ? 'शुद्ध कैप्सूल्स' : 'Capsules'}) · {bundle.durationMonths} {lang === 'hi' ? 'माह का कोर्स' : 'Month Supply'}
                    </p>

                    {/* Price cluster */}
                    <div className="mt-5 flex items-baseline justify-center gap-2">
                      <span className="text-3xl sm:text-4xl font-black tabular-nums">
                        ₹{bundle.price.toLocaleString('en-IN')}
                      </span>
                      <span className={`text-sm line-through tabular-nums ${isPopular ? 'text-[#9cb5aa]' : 'text-[#849a8f]'}`}>
                        ₹{bundle.mrp.toLocaleString('en-IN')}
                      </span>
                    </div>

                    <div className="mt-1">
                      <span
                        className={`inline-block text-xs font-bold px-2.5 py-0.5 rounded ${
                          isPopular
                            ? 'bg-[#0f4d3a] text-[#fcd34d]'
                            : 'bg-[#f0f7f3] text-[#0d5440]'
                        }`}
                      >
                        {lang === 'hi'
                          ? `बचत: ₹${bundle.savings.toLocaleString('en-IN')}`
                          : `You Save: ₹${bundle.savings.toLocaleString('en-IN')}`}
                      </span>
                    </div>
                  </div>

                  {/* Recommendation Tagline */}
                  <div className="my-5 p-3 rounded-xl text-xs text-center font-medium bg-current/5">
                    <span className="font-bold">{lang === 'hi' ? 'अनुशंसा: ' : 'Recommended for: '}</span>
                    {bundle.recommendedFor}
                  </div>

                  {/* Included features list */}
                  <div className="space-y-3 mb-8">
                    <div className={`text-xs font-bold uppercase tracking-wider ${isPopular ? 'text-[#f59e0b]' : 'text-[#0d5440]'}`}>
                      {lang === 'hi' ? 'इस पैक में शामिल है:' : 'Package Inclusions:'}
                    </div>
                    {bundle.bonusFeatures.map((feat, i) => (
                      <div key={i} className="flex items-start gap-2.5 text-xs sm:text-sm">
                        <Check className={`w-4 h-4 shrink-0 mt-0.5 ${isPopular ? 'text-[#f59e0b]' : 'text-[#10b981]'}`} />
                        <span className={isPopular ? 'text-[#e1eee7]' : 'text-[#2a4537]'}>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Order Button */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => onSelectBundle(bundle.id)}
                    className={`w-full py-3.5 px-4 rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.99] shadow-md ${
                      isPopular
                        ? 'bg-[#f59e0b] hover:bg-[#d97706] text-[#14110a]'
                        : 'bg-[#083c2e] hover:bg-[#0c4e3c] text-white'
                    }`}
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>
                      {lang === 'hi'
                        ? `कैश ऑन डिलीवरी पर बुक करें (₹${bundle.price.toLocaleString('en-IN')})`
                        : `Order Free COD (₹${bundle.price.toLocaleString('en-IN')})`}
                    </span>
                  </button>

                  <div className={`mt-3 flex items-center justify-center gap-3 text-[11px] ${isPopular ? 'text-[#a2c8b7]' : 'text-[#6b8578]'}`}>
                    <span className="flex items-center gap-1">
                      <Truck className="w-3 h-3" />
                      {lang === 'hi' ? 'मुफ्त शिपिंग' : 'Free Shipping'}
                    </span>
                    <span>·</span>
                    <span className="flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      {lang === 'hi' ? 'पे ऑन डिलीवरी' : 'Pay on Delivery'}
                    </span>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        {/* Cash On Delivery Assurance Note & Direct Phone Order */}
        <div className="mt-12 p-6 bg-white rounded-2xl border border-[#dce6e0] flex flex-col md:flex-row items-center justify-between gap-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#f0f7f3] text-[#083c2e] flex items-center justify-center font-bold text-lg shrink-0">
              ₹
            </div>
            <div>
              <h4 className="text-sm font-bold text-[#083c2e]">
                {lang === 'hi' ? '100% सुरक्षित डिलीवरी - नकद भुगतान की सुविधा' : '100% Secure Doorstep Cash On Delivery'}
              </h4>
              <p className="text-xs text-[#526b5e]">
                {lang === 'hi'
                  ? 'पार्सल देखने और पुष्टि करने के बाद ही भुगतान करें। पूरे भारत में सभी कूरियर पार्टनर्स द्वारा सुरक्षित डिलीवरी।'
                  : 'Pay cash only after inspecting sealed tamper-proof packaging at your home.'}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <div className="text-xs font-semibold text-[#0d5440] bg-[#eef6f1] px-3 py-2 rounded-lg">
              {lang === 'hi' ? 'फोन पर ऑर्डर करें:' : 'Order by phone:'}
            </div>
            <a
              href={CONTACT_INFO.telUrl}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#083c2e] hover:bg-[#0c4e3c] text-white rounded-lg font-bold text-xs transition-colors shadow-2xs"
            >
              <PhoneCall className="w-3.5 h-3.5 text-[#f59e0b]" />
              <span>{CONTACT_INFO.displayPhone}</span>
            </a>
            <a
              href={CONTACT_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#25d366] hover:bg-[#1faa53] text-white rounded-lg font-bold text-xs transition-colors shadow-2xs"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
