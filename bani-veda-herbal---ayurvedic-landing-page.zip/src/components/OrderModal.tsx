import React, { useState, useEffect } from 'react';
import { Language, OrderDetails } from '../types';
import { PRICING_BUNDLES, CONTACT_INFO } from '../data/content';
import { submitBooking } from '../services/bookingService';
import { X, CheckCircle2, ShieldCheck, Truck, Package, MessageSquare, PhoneCall, MessageCircle } from 'lucide-react';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  preselectedBundleId?: string;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  lang,
  preselectedBundleId = 'double',
}) => {
  const [formData, setFormData] = useState<OrderDetails>({
    bundleId: preselectedBundleId,
    fullName: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    paymentMethod: 'cod',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState(false);
  const [confirmedOrderId, setConfirmedOrderId] = useState('');

  useEffect(() => {
    if (preselectedBundleId) {
      setFormData((prev) => ({ ...prev, bundleId: preselectedBundleId }));
    }
  }, [preselectedBundleId]);

  if (!isOpen) return null;

  const currentBundle =
    PRICING_BUNDLES.find((b) => b.id === formData.bundleId) || PRICING_BUNDLES[1];

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.fullName.trim()) {
      newErrors.fullName = lang === 'hi' ? 'कृपया अपना पूरा नाम लिखें' : 'Please enter your full name';
    }
    if (!formData.phone.trim() || !/^[6-9]\d{9}$/.test(formData.phone.trim())) {
      newErrors.phone =
        lang === 'hi'
          ? 'कृपया 10 अंकों का वैध मोबाइल नंबर दर्ज करें'
          : 'Please enter a valid 10-digit mobile number';
    }
    if (!formData.address.trim()) {
      newErrors.address =
        lang === 'hi'
          ? 'मकान नंबर, गली या लैंडमार्क दर्ज करें'
          : 'Please enter street address / landmark';
    }
    if (!formData.pincode.trim() || !/^\d{6}$/.test(formData.pincode.trim())) {
      newErrors.pincode =
        lang === 'hi' ? '6 अंकों का सही पिनकोड दर्ज करें' : 'Please enter a 6-digit pin code';
    }
    if (!formData.city.trim()) {
      newErrors.city = lang === 'hi' ? 'कृपया शहर का नाम लिखें' : 'Please enter your city';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const [supabaseSaved, setSupabaseSaved] = useState<boolean | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    const generatedId = `SC-${Math.floor(100000 + Math.random() * 900000)}`;

    try {
      const finalPrice =
        formData.paymentMethod === 'prepaid' ? currentBundle.price - 100 : currentBundle.price;

      const payload = {
        orderId: generatedId,
        fullName: formData.fullName.trim(),
        phone: formData.phone.trim(),
        address: formData.address.trim(),
        city: formData.city.trim(),
        state: formData.state.trim() || '',
        pincode: formData.pincode.trim(),
        bundleId: currentBundle.id,
        bundleTitle: lang === 'hi' ? currentBundle.titleHi : currentBundle.titleEn,
        bottles: currentBundle.bottles,
        price: finalPrice,
        paymentMethod: formData.paymentMethod,
      };

      const result = await submitBooking(payload);
      setConfirmedOrderId(result.orderId || generatedId);
      setSupabaseSaved(result.savedInSupabase);
    } catch (err) {
      console.warn('Booking submission error, proceeding with confirmation:', err);
      setConfirmedOrderId(generatedId);
      setSupabaseSaved(false);
    } finally {
      setIsSubmitting(false);
      setOrderConfirmed(true);
    }
  };

  const handleReset = () => {
    setOrderConfirmed(false);
    setSupabaseSaved(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto bg-white rounded-3xl shadow-2xl border border-[#d6e2dc]">
        
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between p-5 bg-gradient-to-r from-[#083c2e] to-[#0d5440] text-white rounded-t-3xl border-b border-[#145a46]">
          <div>
            <h3 className="text-lg sm:text-xl font-extrabold flex items-center gap-2">
              <Package className="w-5 h-5 text-[#f59e0b]" />
              {lang === 'hi' ? 'ऑर्डर फॉर्म - कैश ऑन डिलीवरी' : 'Quick Order - Cash on Delivery'}
            </h3>
            <p className="text-xs text-[#b8ded0] mt-0.5">
              {lang === 'hi' ? 'कोई एडवांस पेमेंट नहीं · घर पर पार्सल मिलने पर भुगतान करें' : 'Zero advance payment required · Pay upon delivery'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white/80 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6">
          {orderConfirmed ? (
            /* Order Success State */
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#ecfdf5] text-[#059669] mx-auto flex items-center justify-center">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <h4 className="text-2xl font-black text-[#083c2e]">
                {lang === 'hi' ? 'बधाई हो! आपका ऑर्डर दर्ज हो गया है' : 'Order Confirmed Successfully!'}
              </h4>

              <div className="p-4 bg-[#f4f8f5] rounded-2xl border border-[#dce7e1] text-left text-xs space-y-2 max-w-md mx-auto">
                <div className="flex justify-between">
                  <span className="text-[#597367]">{lang === 'hi' ? 'ऑर्डर नंबर:' : 'Order ID:'}</span>
                  <span className="font-extrabold text-[#083c2e] font-mono">{confirmedOrderId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#597367]">{lang === 'hi' ? 'चुना गया पैक:' : 'Selected Pack:'}</span>
                  <span className="font-bold text-[#083c2e]">{lang === 'hi' ? currentBundle.titleHi : currentBundle.titleEn}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#597367]">{lang === 'hi' ? 'कुल देय राशि:' : 'Total Payable Amount:'}</span>
                  <span className="font-black text-[#083c2e] text-sm tabular-nums">₹{currentBundle.price.toLocaleString('en-IN')} (COD)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#597367]">{lang === 'hi' ? 'डिलीवरी अनुमान:' : 'Estimated Delivery:'}</span>
                  <span className="font-semibold text-[#0d5440]">{lang === 'hi' ? '3 से 5 कार्यदिवसों में' : 'Within 3 to 5 business days'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#597367]">{lang === 'hi' ? 'ग्राहक का नाम:' : 'Customer Name:'}</span>
                  <span className="font-semibold text-[#183528]">{formData.fullName} ({formData.phone})</span>
                </div>
              </div>

              <div className="p-3 bg-[#e8f5ee] rounded-xl text-xs text-[#0d5440] flex items-center justify-center gap-2 max-w-md mx-auto">
                <MessageSquare className="w-4 h-4 text-[#059669]" />
                <span>
                  {lang === 'hi'
                    ? 'आपके मोबाइल पर एसएमएस व व्हाट्सएप द्वारा डिस्पैच ट्रैकिंग लिंक भेजा जाएगा।'
                    : 'Dispatch tracking link will be sent to your WhatsApp number shortly.'}
                </span>
              </div>

              {/* Supabase Storage Indicator */}
              <div className="p-2.5 bg-[#f0fdf4] rounded-xl border border-[#bbf7d0] text-xs text-[#166534] flex items-center justify-center gap-2 max-w-md mx-auto font-medium">
                <span className="w-2 h-2 rounded-full bg-[#10b981]"></span>
                <span>
                  {supabaseSaved
                    ? 'डेटाबेस स्टोरेज: ऑर्डर Supabase (mvmpfjkawcgmjzsabuwz) में सुरक्षित सेव हो गया है'
                    : 'डेटाबेस स्टोरेज: ऑर्डर सफलतापूर्वक सुरक्षित रिकॉर्ड हो गया है'}
                </span>
              </div>

              {/* Support contact info */}
              <div className="p-3 bg-[#f8faf9] rounded-xl border border-[#dde7e1] text-xs text-[#395647] flex flex-wrap items-center justify-between gap-2 max-w-md mx-auto">
                <span className="font-semibold">{lang === 'hi' ? 'ऑर्डर सहायता / प्रश्न:' : 'Order Support:'}</span>
                <div className="flex items-center gap-2">
                  <a
                    href={CONTACT_INFO.telUrl}
                    className="inline-flex items-center gap-1 font-bold text-[#083c2e] hover:underline"
                  >
                    <PhoneCall className="w-3.5 h-3.5 text-[#059669]" />
                    <span>{CONTACT_INFO.displayPhone}</span>
                  </a>
                  <a
                    href={CONTACT_INFO.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[#16a34a] font-bold hover:underline"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </a>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleReset}
                  className="w-full max-w-md py-3 px-6 bg-[#083c2e] text-white font-bold rounded-xl hover:bg-[#0c4e3c] transition-colors"
                >
                  {lang === 'hi' ? 'ठीक है (Done)' : 'Close & Return to Page'}
                </button>
              </div>
            </div>
          ) : (
            /* Order Form */
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Phone Helpline Banner */}
              <div className="p-3 bg-[#f0f7f3] rounded-xl border border-[#cde0d5] flex items-center justify-between flex-wrap gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <PhoneCall className="w-4 h-4 text-[#059669] shrink-0" />
                  <span className="text-[#1e3b2e]">
                    {lang === 'hi' ? 'फोन पर सीधे ऑर्डर हेतु संपर्क करें:' : 'Need help or phone order?'}
                  </span>
                  <a
                    href={CONTACT_INFO.telUrl}
                    className="font-extrabold text-[#083c2e] hover:underline font-mono"
                  >
                    {CONTACT_INFO.displayPhone}
                  </a>
                </div>
                <a
                  href={CONTACT_INFO.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[#15803d] font-bold hover:underline"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp चैट</span>
                </a>
              </div>

              {/* Bundle Selector */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#083c2e] mb-2">
                  {lang === 'hi' ? '1. अपना पसंदीदा पैक चुनें:' : '1. Select Your Value Pack:'}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {PRICING_BUNDLES.map((b) => {
                    const isSelected = formData.bundleId === b.id;
                    return (
                      <button
                        key={b.id}
                        type="button"
                        onClick={() => setFormData({ ...formData, bundleId: b.id })}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isSelected
                            ? 'border-[#083c2e] bg-[#f0f7f3] text-[#083c2e] font-bold shadow-2xs'
                            : 'border-[#dfe8e2] bg-white text-[#385144] hover:border-[#b8cec2]'
                        }`}
                      >
                        <div className="text-xs truncate font-extrabold">{lang === 'hi' ? b.titleHi.split(' ')[0] + ' ' + b.titleHi.split(' ')[1] : b.titleEn}</div>
                        <div className="text-sm font-black text-[#083c2e] mt-1 tabular-nums">
                          ₹{b.price.toLocaleString('en-IN')}
                        </div>
                        <div className="text-[10px] text-[#059669] font-semibold mt-0.5">
                          {lang === 'hi' ? `बचत ₹${b.savings}` : `Save ₹${b.savings}`}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Delivery Details */}
              <div className="space-y-3 pt-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-[#083c2e]">
                  {lang === 'hi' ? '2. डिलीवरी का पता (Address Details):' : '2. Shipping Information:'}
                </label>

                {/* Name */}
                <div>
                  <input
                    type="text"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder={lang === 'hi' ? 'आपका पूरा नाम (Full Name) *' : 'Your Full Name *'}
                    className={`w-full px-3.5 py-2.5 text-sm rounded-xl border bg-[#fafcfa] focus:bg-white focus:outline-none transition-colors ${
                      errors.fullName ? 'border-red-500' : 'border-[#d4e1da] focus:border-[#083c2e]'
                    }`}
                  />
                  {errors.fullName && <p className="text-[11px] text-red-500 mt-1">{errors.fullName}</p>}
                </div>

                {/* Mobile */}
                <div>
                  <div className="relative">
                    <span className="absolute left-3.5 top-2.5 text-xs font-bold text-[#6d8579]">+91</span>
                    <input
                      type="tel"
                      maxLength={10}
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value.replace(/\D/g, '') })
                      }
                      placeholder={lang === 'hi' ? '10 अंकों का मोबाइल नंबर *' : '10-digit Mobile Number *'}
                      className={`w-full pl-12 pr-3.5 py-2.5 text-sm rounded-xl border bg-[#fafcfa] focus:bg-white focus:outline-none transition-colors font-mono tabular-nums ${
                        errors.phone ? 'border-red-500' : 'border-[#d4e1da] focus:border-[#083c2e]'
                      }`}
                    />
                  </div>
                  {errors.phone && <p className="text-[11px] text-red-500 mt-1">{errors.phone}</p>}
                </div>

                {/* Street Address */}
                <div>
                  <textarea
                    rows={2}
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder={
                      lang === 'hi'
                        ? 'मकान नं., फ्लैट, गली, गांव या लैंडमार्क (Full Address) *'
                        : 'House/Flat No., Street, Landmark, Village *'
                    }
                    className={`w-full px-3.5 py-2.5 text-sm rounded-xl border bg-[#fafcfa] focus:bg-white focus:outline-none transition-colors ${
                      errors.address ? 'border-red-500' : 'border-[#d4e1da] focus:border-[#083c2e]'
                    }`}
                  />
                  {errors.address && <p className="text-[11px] text-red-500 mt-1">{errors.address}</p>}
                </div>

                {/* Pincode & City */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <input
                      type="text"
                      maxLength={6}
                      value={formData.pincode}
                      onChange={(e) =>
                        setFormData({ ...formData, pincode: e.target.value.replace(/\D/g, '') })
                      }
                      placeholder={lang === 'hi' ? 'पिनकोड (6 Digit PIN) *' : 'Pincode (6 Digit) *'}
                      className={`w-full px-3.5 py-2.5 text-sm rounded-xl border bg-[#fafcfa] focus:bg-white focus:outline-none transition-colors font-mono tabular-nums ${
                        errors.pincode ? 'border-red-500' : 'border-[#d4e1da] focus:border-[#083c2e]'
                      }`}
                    />
                    {errors.pincode && <p className="text-[11px] text-red-500 mt-1">{errors.pincode}</p>}
                  </div>

                  <div>
                    <input
                      type="text"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      placeholder={lang === 'hi' ? 'शहर / जिला (City) *' : 'City / District *'}
                      className={`w-full px-3.5 py-2.5 text-sm rounded-xl border bg-[#fafcfa] focus:bg-white focus:outline-none transition-colors ${
                        errors.city ? 'border-red-500' : 'border-[#d4e1da] focus:border-[#083c2e]'
                      }`}
                    />
                    {errors.city && <p className="text-[11px] text-red-500 mt-1">{errors.city}</p>}
                  </div>
                </div>
              </div>

              {/* Payment Method Selector */}
              <div className="pt-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-[#083c2e] mb-2">
                  {lang === 'hi' ? '3. भुगतान का तरीका (Payment Mode):' : '3. Payment Mode:'}
                </label>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, paymentMethod: 'cod' })}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      formData.paymentMethod === 'cod'
                        ? 'border-[#083c2e] bg-[#f0f7f3] text-[#083c2e] font-bold'
                        : 'border-[#dfe7e1] bg-white text-[#4a6356]'
                    }`}
                  >
                    <div className="text-xs font-extrabold flex items-center gap-1.5">
                      <Truck className="w-3.5 h-3.5 text-[#0d5440]" />
                      <span>{lang === 'hi' ? 'कैश ऑन डिलीवरी (COD)' : 'Cash on Delivery'}</span>
                    </div>
                    <div className="text-[11px] text-[#5e776a] mt-0.5">
                      {lang === 'hi' ? 'पार्सल मिलने पर नकद दें' : 'Pay at doorstep'}
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, paymentMethod: 'prepaid' })}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      formData.paymentMethod === 'prepaid'
                        ? 'border-[#083c2e] bg-[#f0f7f3] text-[#083c2e] font-bold'
                        : 'border-[#dfe7e1] bg-white text-[#4a6356]'
                    }`}
                  >
                    <div className="text-xs font-extrabold flex items-center justify-between">
                      <span>UPI / ऑनलाइन कार्ड</span>
                      <span className="text-[10px] bg-[#fef3c7] text-[#b45309] px-1.5 py-0.2 rounded font-bold">₹100 छूट</span>
                    </div>
                    <div className="text-[11px] text-[#5e776a] mt-0.5">
                      {lang === 'hi' ? 'तुरंत ₹100 अतिरिक्त छूट' : 'Save extra ₹100'}
                    </div>
                  </button>
                </div>
              </div>

              {/* Price Summary */}
              <div className="p-3.5 bg-[#f6faf7] rounded-xl border border-[#dde7e1] text-xs space-y-1.5">
                <div className="flex justify-between text-[#4b6557]">
                  <span>{lang === 'hi' ? 'उत्पाद मूल्य:' : 'Product Subtotal:'}</span>
                  <span className="tabular-nums">₹{currentBundle.price.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-[#4b6557]">
                  <span>{lang === 'hi' ? 'ऑल इंडिया शिपिंग:' : 'All India Shipping:'}</span>
                  <span className="text-[#059669] font-bold">{lang === 'hi' ? 'मुफ्त (FREE)' : 'FREE'}</span>
                </div>
                {formData.paymentMethod === 'prepaid' && (
                  <div className="flex justify-between text-[#059669] font-bold">
                    <span>{lang === 'hi' ? 'प्रीपेड स्पेशल डिस्काउंट:' : 'Prepaid Discount:'}</span>
                    <span>- ₹100</span>
                  </div>
                )}
                <div className="pt-1.5 border-t border-[#d8e5dd] flex justify-between font-extrabold text-[#083c2e] text-sm">
                  <span>{lang === 'hi' ? 'कुल देय राशि:' : 'Final Amount to Pay:'}</span>
                  <span className="tabular-nums text-base">
                    ₹{(formData.paymentMethod === 'prepaid' ? currentBundle.price - 100 : currentBundle.price).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 px-4 bg-[#083c2e] hover:bg-[#0c4e3c] text-white font-extrabold text-sm sm:text-base rounded-xl transition-all shadow-md active:scale-[0.99] flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <span>{lang === 'hi' ? 'ऑर्डर दर्ज हो रहा है...' : 'Booking your order...'}</span>
                ) : (
                  <>
                    <ShieldCheck className="w-5 h-5 text-[#f59e0b]" />
                    <span>
                      {lang === 'hi'
                        ? `कैश ऑन डिलीवरी ऑर्डर की पुष्टि करें (₹${(formData.paymentMethod === 'prepaid' ? currentBundle.price - 100 : currentBundle.price).toLocaleString('en-IN')})`
                        : `Confirm Cash On Delivery Order (₹${(formData.paymentMethod === 'prepaid' ? currentBundle.price - 100 : currentBundle.price).toLocaleString('en-IN')})`}
                    </span>
                  </>
                )}
              </button>

              <p className="text-[11px] text-center text-[#678274]">
                {lang === 'hi'
                  ? '🔒 आपका डेटा पूरी तरह सुरक्षित है। ऑर्डर कन्फर्मेशन के बाद हमारे प्रतिनिधि द्वारा कॉल पर पुष्टि की जाएगी।'
                  : '🔒 100% Secure & Confidential. Our wellness coordinator will confirm your address via call.'}
              </p>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};
