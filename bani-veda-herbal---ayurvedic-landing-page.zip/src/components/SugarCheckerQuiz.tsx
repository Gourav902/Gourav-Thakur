import React, { useState } from 'react';
import { Language } from '../types';
import { Activity, Check, Clock, Sparkles, AlertCircle, ShoppingBag } from 'lucide-react';

interface SugarCheckerQuizProps {
  lang: Language;
  onSelectBundleAndOrder: (bundleId: string) => void;
}

const RANGES = [
  { id: 'borderline', labelHi: '100 - 130 mg/dL (शुरुआती / प्रीडायबिटीज)', labelEn: '100 - 130 mg/dL (Pre-diabetic)', level: 'mild' },
  { id: 'moderate', labelHi: '131 - 180 mg/dL (मध्यम उच्च स्तर)', labelEn: '131 - 180 mg/dL (Moderately High)', level: 'moderate' },
  { id: 'high', labelHi: '181 - 240 mg/dL (उच्च स्तर)', labelEn: '181 - 240 mg/dL (High Glucose)', level: 'high' },
  { id: 'severe', labelHi: '240+ mg/dL (अति उच्च / अनियंत्रित)', labelEn: '240+ mg/dL (Very High / Severe)', level: 'severe' },
];

const SYMPTOMS = [
  { id: 'urination', labelHi: 'रात में बार-बार पेशाब जाना (Frequent Urination)', labelEn: 'Frequent Urination at Night' },
  { id: 'fatigue', labelHi: 'खाना खाने के बाद तेज सुस्ती व आलस (Post-meal Fatigue)', labelEn: 'Severe Post-meal Fatigue' },
  { id: 'tingling', labelHi: 'पैरों के तलवों में जलन व झनझनाहट (Burning Feet / Tingling)', labelEn: 'Feet Burning & Tingling Sensation' },
  { id: 'cravings', labelHi: 'मीठा खाने की अनियंत्रित तलब (Sweet Cravings)', labelEn: 'Uncontrollable Sweet Cravings' },
  { id: 'thirst', labelHi: 'गला सूखना व बार-बार प्यास लगना (Dry Mouth & Excessive Thirst)', labelEn: 'Excessive Thirst & Dry Throat' },
  { id: 'weight', labelHi: 'अचानक वजन घटना या कमजोरी (Sudden Weakness / Weight Loss)', labelEn: 'Unexplained Weight Loss or Weakness' },
];

export const SugarCheckerQuiz: React.FC<SugarCheckerQuizProps> = ({ lang, onSelectBundleAndOrder }) => {
  const [selectedRange, setSelectedRange] = useState<string>('moderate');
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>(['urination', 'fatigue', 'cravings']);

  const toggleSymptom = (id: string) => {
    setSelectedSymptoms((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const getRecommendation = () => {
    if (selectedRange === 'borderline') {
      return {
        dosageHi: '1 कैप्सूल सुबह नाश्ते से 30 मिनट पहले और 1 कैप्सूल रात के खाने से पहले',
        dosageEn: '1 capsule 30 min before breakfast and 1 capsule before dinner with lukewarm water',
        recommendedPackHi: '1 से 2 माह का पैक (स्टार्टर या स्टेबिलाइज़र)',
        recommendedPackEn: '1 to 2 Months Pack (Starter / Stabilizer)',
        bundleId: 'double',
        timelineHi: '15-20 दिनों में शुगर स्तर स्थिर होगा और ऊर्जा वापस लौटेगी।',
        timelineEn: 'Noticeable sugar stability and refreshed energy in 15-20 days.',
      };
    } else if (selectedRange === 'moderate') {
      return {
        dosageHi: '1 कैप्सूल सुबह व 1 कैप्सूल रात को गुनगुने पानी के साथ (नियमित)',
        dosageEn: '1 capsule morning and 1 capsule night with lukewarm water consistently',
        recommendedPackHi: '2 माह का स्टेबिलाइज़र पैक (सर्वाधिक अनुशंसित)',
        recommendedPackEn: '2 Months Stabilizer Pack (Most Recommended)',
        bundleId: 'double',
        timelineHi: '30 से 45 दिनों में फास्टिंग शुगर में 35-50 mg/dL तक की राहत और तलवों की जलन शांत होगी।',
        timelineEn: '35-50 mg/dL fasting drop and relief from foot burning within 30 to 45 days.',
      };
    } else {
      return {
        dosageHi: '2 कैप्सूल सुबह नाश्ते से पहले व 2 कैप्सूल रात खाने से पहले (तीव्र आयुर्वेदिक पोषण)',
        dosageEn: '2 capsules morning and 2 capsules evening with lukewarm water',
        recommendedPackHi: '3 माह का पूर्ण कायाकल्प पैक (Complete Rebalance)',
        recommendedPackEn: '3 Months Complete Rebalance Pack',
        bundleId: 'triple',
        timelineHi: 'HbA1c को 7 से नीचे लाने और बीटा-कोशिकाओं के संपूर्ण पुनरुद्धार हेतु 90 दिनों का पूर्ण कोर्स आवश्यक है।',
        timelineEn: 'Full 90-day cycle recommended for bringing HbA1c below 7 and restoring cellular insulin response.',
      };
    }
  };

  const rec = getRecommendation();

  return (
    <section id="calculator" className="py-14 sm:py-20 bg-[#f4f7f4] border-b border-[#e1eae3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#e4ede7] text-[#0d5440] text-xs font-bold rounded-md tracking-wider uppercase mb-3">
            <Activity className="w-3.5 h-3.5 text-[#0d5440]" />
            <span>{lang === 'hi' ? 'इंटरएक्टिव आयुर्वेदिक हेल्थ असेसमेंट' : 'Interactive Ayurvedic Health Assessment'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#093226] tracking-tight">
            {lang === 'hi'
              ? 'अपना शुगर लेवल चुनें और अपनी व्यक्तिगत खुराक (Dosage) जानें'
              : 'Select Your Fasting Range & Discover Your Personalized Dose'}
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#476053]">
            {lang === 'hi'
              ? 'आयुर्वेद में हर शरीर की प्रकृति और शुगर का स्तर भिन्न होता है। नीचे अपना विवरण चुनें और जानें आपके लिए सही डोज़ क्या है।'
              : 'In Ayurveda, dosage varies by glucose severity and Prakriti. Select your parameters below for an instant personalized protocol.'}
          </p>
        </div>

        {/* Interactive Assessment Tool */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Inputs Column */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-[#d8e3dc] shadow-sm space-y-7">
            
            {/* Step 1: Range Selection */}
            <div>
              <label className="block text-sm font-bold text-[#0a3125] mb-3">
                <span className="text-[#0d5440] mr-1.5">1.</span>
                {lang === 'hi'
                  ? 'आपकी सुबह की फास्टिंग ब्लड शुगर (Fasting Sugar Level) कितनी रहती है?'
                  : 'What is your typical Morning Fasting Blood Sugar?'}
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {RANGES.map((range) => {
                  const isSelected = selectedRange === range.id;
                  return (
                    <button
                      key={range.id}
                      type="button"
                      onClick={() => setSelectedRange(range.id)}
                      className={`text-left p-3.5 rounded-xl border text-xs sm:text-sm transition-all flex items-center justify-between ${
                        isSelected
                          ? 'border-[#083c2e] bg-[#f0f6f2] text-[#083c2e] font-bold shadow-2xs'
                          : 'border-[#e0ebe3] bg-white text-[#334b3f] hover:border-[#b8d0c2]'
                      }`}
                    >
                      <span>{lang === 'hi' ? range.labelHi : range.labelEn}</span>
                      <span
                        className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ml-2 ${
                          isSelected ? 'border-[#083c2e] bg-[#083c2e] text-white' : 'border-[#b5c7bc]'
                        }`}
                      >
                        {isSelected && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Symptoms Multi-Select */}
            <div>
              <label className="block text-sm font-bold text-[#0a3125] mb-2">
                <span className="text-[#0d5440] mr-1.5">2.</span>
                {lang === 'hi'
                  ? 'आप इनमें से किन लक्षणों का अनुभव कर रहे हैं? (जो लागू हों चुनें)'
                  : 'Which of these symptoms do you experience? (Select all that apply)'}
              </label>
              <p className="text-xs text-[#627a6d] mb-3">
                {lang === 'hi' ? 'यह आपके शरीर के कफ-पित्त असंतुलन को समझने में मदद करता है।' : 'Helps identify dosha aggravation and pancreatic fatigue.'}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {SYMPTOMS.map((sym) => {
                  const isChecked = selectedSymptoms.includes(sym.id);
                  return (
                    <button
                      key={sym.id}
                      type="button"
                      onClick={() => toggleSymptom(sym.id)}
                      className={`text-left p-3 rounded-lg border text-xs sm:text-sm transition-all flex items-center justify-between ${
                        isChecked
                          ? 'border-[#0d5440] bg-[#eef6f1] text-[#083c2e] font-semibold'
                          : 'border-[#e4ede7] bg-[#fafcfa] text-[#42594d] hover:border-[#ccdcd2]'
                      }`}
                    >
                      <span className="leading-snug">{lang === 'hi' ? sym.labelHi : sym.labelEn}</span>
                      <span
                        className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ml-2 ${
                          isChecked ? 'border-[#0d5440] bg-[#0d5440] text-white' : 'border-[#b6c7bc] bg-white'
                        }`}
                      >
                        {isChecked && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Results Column */}
          <div className="lg:col-span-5 bg-gradient-to-b from-[#083c2e] to-[#05261d] text-white p-6 sm:p-8 rounded-3xl shadow-xl border border-[#144b3c] space-y-6">
            
            <div className="flex items-center justify-between pb-4 border-b border-[#1b5041]">
              <span className="text-xs uppercase font-extrabold tracking-wider text-[#f59e0b] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                {lang === 'hi' ? 'वैयक्तिकृत आयुर्वेदिक रिपोर्ट' : 'Personalized Ayurvedic Report'}
              </span>
              <span className="text-xs bg-[#0e4d3a] px-2.5 py-1 rounded text-[#a6dec7] font-semibold">
                {selectedSymptoms.length} {lang === 'hi' ? 'लक्षण पहचाने गए' : 'Symptoms Tracked'}
              </span>
            </div>

            {/* Recommended Dosage Card */}
            <div className="bg-[#0b4737]/80 backdrop-blur-sm p-4 rounded-2xl border border-[#1a5a47]">
              <div className="text-xs uppercase font-bold text-[#b7e2d1] tracking-wider mb-1 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[#f59e0b]" />
                {lang === 'hi' ? 'अनुशंसित दैनिक सेवन (Recommended Dosage)' : 'Recommended Daily Dosage'}
              </div>
              <p className="text-sm sm:text-base font-bold text-white mt-1">
                {lang === 'hi' ? rec.dosageHi : rec.dosageEn}
              </p>
              <p className="text-xs text-[#a2cbba] mt-2">
                {lang === 'hi'
                  ? 'शुद्ध 6-इन-1 कैप्सूल में नीम, करेला और गुड़मार का रस तुरंत आंतों में अवशोषित होता है।'
                  : 'Fast absorbing bioactives target post-prandial spikes naturally.'}
              </p>
            </div>

            {/* Expected Result Timeline */}
            <div className="space-y-2 text-xs">
              <span className="font-bold text-[#f59e0b] uppercase tracking-wider block">
                {lang === 'hi' ? 'अपेक्षित सुधार समय-सीमा:' : 'Expected Relief Timeline:'}
              </span>
              <p className="text-[#d8eae1] leading-relaxed">
                {lang === 'hi' ? rec.timelineHi : rec.timelineEn}
              </p>
            </div>

            {/* Best Suited Pack */}
            <div className="pt-2 border-t border-[#1b5041]">
              <div className="text-xs text-[#9cc0b1] mb-1">
                {lang === 'hi' ? 'आपके स्तर के लिए सबसे उपयुक्त पैकेज:' : 'Best Suited Value Pack For You:'}
              </div>
              <div className="text-base font-extrabold text-white">
                {lang === 'hi' ? rec.recommendedPackHi : rec.recommendedPackEn}
              </div>

              <button
                type="button"
                onClick={() => onSelectBundleAndOrder(rec.bundleId)}
                className="w-full mt-4 flex items-center justify-center gap-2 py-3 px-5 bg-[#f59e0b] hover:bg-[#d97706] text-[#191612] font-extrabold text-sm rounded-xl transition-all shadow-md active:scale-[0.99]"
              >
                <ShoppingBag className="w-4 h-4 text-[#191612]" />
                <span>
                  {lang === 'hi' ? 'इस पैकेज को कैश ऑन डिलीवरी पर बुक करें' : 'Order This Pack with Free COD'}
                </span>
              </button>

              <div className="flex items-center justify-center gap-2 mt-3 text-[11px] text-[#9fc4b5]">
                <AlertCircle className="w-3.5 h-3.5 text-[#f59e0b]" />
                <span>
                  {lang === 'hi' ? 'कोई अग्रिम भुगतान नहीं · घर पर पार्सल मिलने पर भुगतान करें' : 'Zero upfront payment · Pay at doorstep'}
                </span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
