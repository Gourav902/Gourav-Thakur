import React from 'react';
import { Language } from '../types';
import { TESTIMONIALS } from '../data/content';
import { Star, CheckCircle, TrendingDown } from 'lucide-react';

interface TestimonialsProps {
  lang: Language;
}

export const Testimonials: React.FC<TestimonialsProps> = ({ lang }) => {
  return (
    <section className="py-14 sm:py-20 bg-[#f7faf8] border-b border-[#e1eae3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#e3ede6] text-[#0d5440] text-xs font-bold rounded-md tracking-wider uppercase mb-3">
            <CheckCircle className="w-3.5 h-3.5 text-[#0d5440]" />
            <span>{lang === 'hi' ? 'सत्यापित ग्राहकों के अनुभव' : 'Verified Customer Experiences'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#093226] tracking-tight text-balance">
            {lang === 'hi'
              ? '45,000+ भारतीयों ने पाया प्राकृतिक शुगर नियंत्रण'
              : 'Real People. Concrete Results. 45,000+ Rebalanced Lives.'}
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#465f52]">
            {lang === 'hi'
              ? 'देखें हमारे ग्राहकों ने शुगर केयर (6-in-1) के नियमित सेवन से फास्टिंग और HbA1c में कैसे ठोस सुधार पाया।'
              : 'Verifiable clinical changes documented by verified Sugar Care purchasers across India.'}
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              className="bg-white rounded-3xl p-6 sm:p-7 border border-[#dce6df] shadow-2xs flex flex-col justify-between hover:border-[#b4cdc0] transition-all"
            >
              <div>
                {/* Top star rating and timeframe */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1 text-[#f59e0b]">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  <span className="text-xs font-bold text-[#0d5440] bg-[#eef6f1] px-2.5 py-0.5 rounded-full">
                    {t.timeframe}
                  </span>
                </div>

                {/* Quantitative Metric Tracker Box */}
                <div className="p-3.5 bg-[#f6f9f7] rounded-2xl border border-[#e2ece6] mb-4 space-y-2">
                  <div className="flex items-center justify-between text-xs font-semibold text-[#1e392c]">
                    <span>{lang === 'hi' ? 'फास्टिंग शुगर:' : 'Fasting Sugar:'}</span>
                    <span className="flex items-center gap-1 text-[#083c2e] font-extrabold tabular-nums">
                      <span className="text-[#a14332] line-through">{t.beforeFasting}</span>
                      <span>→</span>
                      <span className="text-[#059669] font-black">{t.afterFasting} mg/dL</span>
                      <TrendingDown className="w-3.5 h-3.5 text-[#059669]" />
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs font-semibold text-[#1e392c]">
                    <span>{lang === 'hi' ? 'HbA1c लेवल:' : 'HbA1c Level:'}</span>
                    <span className="flex items-center gap-1 text-[#083c2e] font-extrabold tabular-nums">
                      <span className="text-[#a14332] line-through">{t.beforeHba1c}%</span>
                      <span>→</span>
                      <span className="text-[#059669] font-black">{t.afterHba1c}%</span>
                    </span>
                  </div>
                </div>

                {/* Customer Quote */}
                <p className="text-xs sm:text-sm text-[#385144] leading-relaxed italic mb-6">
                  "{lang === 'hi' ? t.quoteHi : t.quoteEn}"
                </p>
              </div>

              {/* Author Info */}
              <div className="pt-4 border-t border-[#e8efe9] flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#083c2e] text-white flex items-center justify-center font-bold text-sm shrink-0">
                  {t.avatarLetter}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#083c2e] flex items-center gap-1.5">
                    <span>{t.name}</span>
                    <span className="text-xs text-[#10b981]" title="Verified Purchase">●</span>
                  </h4>
                  <p className="text-xs text-[#627c6f]">
                    {t.age} {lang === 'hi' ? 'वर्ष' : 'yrs'} · {t.city}
                  </p>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
