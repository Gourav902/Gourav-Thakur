import React, { useState } from 'react';
import { Language } from '../types';
import { PRICING_BUNDLES, CONTACT_INFO } from '../data/content';
import { submitBooking } from '../services/bookingService';
import { Truck, ShieldCheck, CheckCircle2, MessageSquare, PhoneCall, Sparkles } from 'lucide-react';

interface DirectOrderFormProps {
  lang: Language;
  initialBundleId?: string;
  onOrderSuccess?: (orderId: string) => void;
}

export const DirectOrderForm: React.FC<DirectOrderFormProps> = ({
  lang,
  initialBundleId = 'single',
  onOrderSuccess,
}) => {
  const [selectedBundleId, setSelectedBundleId] = useState<string>(initialBundleId);
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [city, setCity] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'prepaid'>('cod');

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState(false);
  const [confirmedOrderId, setConfirmedOrderId] = useState('');
  const [supabaseSaved, setSupabaseSaved] = useState<boolean | null>(null);

  const currentBundle =
    PRICING_BUNDLES.find((b) => b.id === selectedBundleId) || PRICING_BUNDLES[0];

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!fullName.trim()) {
      errs.fullName = lang === 'hi' ? 'कृपया अपना पूरा नाम लिखें' : 'Please enter your full name';
    }
    if (!phone.trim() || !/^[6-9]\d{9}$/.test(phone.trim())) {
      errs.phone =
        lang === 'hi'
          ? 'कृपया 10 अंकों का वैध मोबाइल नंबर लिखें'
          : 'Please enter a valid 10-digit mobile number';
    }
    if (!address.trim()) {
      errs.address =
        lang === 'hi'
          ? 'मकान नं., फ्लैट, गली या लैंडमार्क दर्ज करें'
          : 'Please enter your street address / landmark';
    }
    if (!pincode.trim() || !/^\d{6}$/.test(pincode.trim())) {
      errs.pincode =
        lang === 'hi' ? '6 अंकों का सही पिनकोड दर्ज करें' : 'Please enter a 6-digit pin code';
    }
    if (!city.trim()) {
      errs.city = lang === 'hi' ? 'कृपया शहर का नाम दर्ज करें' : 'Please enter your city';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    const generatedId = `SC-${Math.floor(100000 + Math.random() * 900000)}`;

    try {
      const finalPrice =
        paymentMethod === 'prepaid' ? currentBundle.price - 100 : currentBundle.price;

      const payload = {
        orderId: generatedId,
        fullName: fullName.trim(),
        phone: phone.trim(),
        address: address.trim(),
        city: city.trim(),
        state: '',
        pincode: pincode.trim(),
        bundleId: currentBundle.id,
        bundleTitle: lang === 'hi' ? currentBundle.titleHi : currentBundle.titleEn,
        bottles: currentBundle.bottles,
        price: finalPrice,
        paymentMethod,
      };

      const result = await submitBooking(payload);
      setConfirmedOrderId(result.orderId || generatedId);
      setSupabaseSaved(result.savedInSupabase);
      if (onOrderSuccess) onOrderSuccess(result.orderId || generatedId);
    } catch (err) {
      console.warn('Booking submission error:', err);
      setConfirmedOrderId(generatedId);
      setSupabaseSaved(false);
    } finally {
      setIsSubmitting(false);
      setOrderConfirmed(true);
    }
  };

  const handleReset = () => {
    setOrderConfirmed(false);
    setFullName('');
    setPhone('');
    setAddress('');
    setPincode('');
    setCity('');
    setErrors({});
  };

  const finalAmount =
    paymentMethod === 'prepaid' ? currentBundle.price - 100 : currentBundle.price;

  if (orderConfirmed) {
    return (
      <div className="bg-[#f0f9f4] border-2 border-[#10b981] rounded-3xl p-6 sm:p-7 text-center space-y-4 animate-in fade-in duration-300">
        <div className="w-16 h-16 rounded-full bg-[#ecfdf5] text-[#059669] mx-auto flex items-center justify-center shadow-xs">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <div>
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#059669] bg-[#d1fae5] px-3 py-1 rounded-full">
            {lang === 'hi' ? 'ऑर्डर सफलतापूर्वक दर्ज हुआ' : 'Order Placed Successfully'}
          </span>
          <h3 className="text-2xl font-black text-[#083c2e] mt-2">
            {lang === 'hi' ? 'धन्यवाद, आपका ऑर्डर कन्फर्म हो गया है!' : 'Thank you! Your order is confirmed!'}
          </h3>
          <p className="text-xs text-[#385949] mt-1">
            {lang === 'hi' ? 'ऑर्डर आईडी:' : 'Order ID:'}{' '}
            <strong className="font-mono text-sm text-[#083c2e]">{confirmedOrderId}</strong>
          </p>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-[#d2e4db] text-left text-xs space-y-2 max-w-md mx-auto shadow-2xs">
          <div className="flex justify-between">
            <span className="text-[#597367]">{lang === 'hi' ? 'ग्राहक:' : 'Customer:'}</span>
            <span className="font-bold text-[#083c2e]">{fullName} ({phone})</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#597367]">{lang === 'hi' ? 'डिलीवरी पता:' : 'Delivery Address:'}</span>
            <span className="font-medium text-[#083c2e] text-right truncate max-w-[200px]">{address}, {city} - {pincode}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#597367]">{lang === 'hi' ? 'चुना गया पैक:' : 'Pack:'}</span>
            <span className="font-bold text-[#083c2e]">
              {lang === 'hi' ? currentBundle.titleHi : currentBundle.titleEn}
            </span>
          </div>
          <div className="flex justify-between border-t border-[#e2eee7] pt-1.5 font-extrabold text-sm text-[#083c2e]">
            <span>{lang === 'hi' ? 'कुल देय (COD):' : 'Pay on Delivery:'}</span>
            <span className="tabular-nums text-[#083c2e]">₹{finalAmount.toLocaleString('en-IN')}</span>
          </div>
        </div>

        <div className="p-3 bg-white/80 rounded-xl text-xs text-[#0d5440] flex items-center justify-center gap-2 max-w-md mx-auto border border-[#d2e4db]">
          <MessageSquare className="w-4 h-4 text-[#059669] shrink-0" />
          <span>
            {lang === 'hi'
              ? 'डिस्पैच ट्रैकिंग लिंक आपके WhatsApp नंबर पर भेजा जाएगा।'
              : 'Dispatch tracking updates will be sent to your WhatsApp.'}
          </span>
        </div>

        {supabaseSaved !== false && (
          <p className="text-[11px] text-[#059669] font-medium flex items-center justify-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#10b981]"></span>
            <span>Supabase डेटाबेस में सुरक्षित सेव हो गया है</span>
          </p>
        )}

        <button
          type="button"
          onClick={handleReset}
          className="mt-2 text-xs font-bold text-[#083c2e] hover:underline cursor-pointer"
        >
          {lang === 'hi' ? 'नया ऑर्डर दर्ज करें' : 'Place another order'}
        </button>
      </div>
    );
  }

  return (
    <div id="quick-order-form" className="bg-white rounded-3xl border-2 border-[#10b981]/50 p-5 sm:p-6 shadow-xl relative overflow-hidden">
      {/* Top Banner Tag */}
      <div className="flex items-center justify-between pb-3.5 mb-4 border-b border-[#e5efe8]">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-[#10b981] animate-ping inline-block"></span>
          <span className="text-xs font-extrabold text-[#083c2e] uppercase tracking-wider">
            {lang === 'hi' ? 'सीधे ऑर्डर करें (कैश ऑन डिलीवरी)' : 'Direct Order Form (Free COD)'}
          </span>
        </div>
        <span className="text-[11px] font-bold text-[#b45309] bg-[#fef3c7] px-2.5 py-0.5 rounded-full flex items-center gap-1">
          <Truck className="w-3 h-3 text-[#b45309]" />
          {lang === 'hi' ? 'फ्री डिलीवरी' : 'Free Shipping'}
        </span>
      </div>

      <p className="text-xs text-[#3b5547] mb-4">
        {lang === 'hi'
          ? 'दवा मंगवाने के लिए नीचे अपना विवरण भरें। पार्सल हाथ में मिलने पर ही नकद भुगतान करें:'
          : 'Fill your delivery details below to order medicine. Pay cash only upon home delivery:'}
      </p>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Step 1: Pack Selection Radios */}
        <div>
          <label className="block text-[11px] font-extrabold text-[#083c2e] uppercase tracking-wider mb-1.5">
            {lang === 'hi' ? '1. अपना पैक चुनें:' : '1. Select Your Value Pack:'}
          </label>
          <div className="grid grid-cols-3 gap-2">
            {PRICING_BUNDLES.map((b) => {
              const isSelected = selectedBundleId === b.id;
              return (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => setSelectedBundleId(b.id)}
                  className={`p-2.5 rounded-xl border text-left transition-all relative ${
                    isSelected
                      ? 'border-[#083c2e] bg-[#f0f7f3] text-[#083c2e] font-bold ring-2 ring-[#083c2e]/20'
                      : 'border-[#dfe8e2] bg-[#fdfefd] text-[#3f574a] hover:border-[#b4cec0]'
                  }`}
                >
                  {b.popular && (
                    <span className="absolute -top-2 right-1.5 bg-[#f59e0b] text-[#14120f] text-[9px] font-extrabold px-1.5 py-0.2 rounded-full uppercase">
                      पॉपुलर
                    </span>
                  )}
                  <div className="text-[11px] font-extrabold truncate">
                    {lang === 'hi' ? `${b.bottles} बॉटल` : `${b.bottles} Bottle`}
                  </div>
                  <div className="text-xs font-black text-[#083c2e] mt-0.5 tabular-nums">
                    ₹{b.price.toLocaleString('en-IN')}
                  </div>
                  <div className="text-[9px] text-[#059669] font-semibold mt-0.5">
                    बचत ₹{b.savings}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 2: Customer Details Inputs */}
        <div className="space-y-2.5 pt-1">
          <label className="block text-[11px] font-extrabold text-[#083c2e] uppercase tracking-wider">
            {lang === 'hi' ? '2. डिलीवरी का पता भरें:' : '2. Enter Delivery Details:'}
          </label>

          {/* Full Name */}
          <div>
            <input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder={lang === 'hi' ? 'आपका पूरा नाम (Full Name) *' : 'Your Full Name *'}
              className={`w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border bg-[#fafcfa] focus:bg-white focus:outline-none transition-colors ${
                errors.fullName ? 'border-red-500' : 'border-[#d2ded6] focus:border-[#083c2e]'
              }`}
            />
            {errors.fullName && <p className="text-[10px] text-red-500 mt-1">{errors.fullName}</p>}
          </div>

          {/* Mobile Number */}
          <div>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-xs font-bold text-[#627a6e]">+91</span>
              <input
                type="tel"
                maxLength={10}
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                placeholder={lang === 'hi' ? '10 अंकों का मोबाइल नंबर *' : '10-digit Mobile Number *'}
                className={`w-full pl-12 pr-3.5 py-2.5 text-xs sm:text-sm rounded-xl border bg-[#fafcfa] focus:bg-white focus:outline-none transition-colors font-mono tabular-nums ${
                  errors.phone ? 'border-red-500' : 'border-[#d2ded6] focus:border-[#083c2e]'
                }`}
              />
            </div>
            {errors.phone && <p className="text-[10px] text-red-500 mt-1">{errors.phone}</p>}
          </div>

          {/* Address */}
          <div>
            <textarea
              rows={2}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder={
                lang === 'hi'
                  ? 'मकान नं., फ्लैट, गली, गांव या लैंडमार्क (Full Address) *'
                  : 'House/Flat No., Street, Landmark *'
              }
              className={`w-full px-3.5 py-2 text-xs sm:text-sm rounded-xl border bg-[#fafcfa] focus:bg-white focus:outline-none transition-colors ${
                errors.address ? 'border-red-500' : 'border-[#d2ded6] focus:border-[#083c2e]'
              }`}
            />
            {errors.address && <p className="text-[10px] text-red-500 mt-0.5">{errors.address}</p>}
          </div>

          {/* Pincode & City */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <input
                type="text"
                maxLength={6}
                value={pincode}
                onChange={(e) => setPincode(e.target.value.replace(/\D/g, ''))}
                placeholder={lang === 'hi' ? 'पिनकोड (6 Digit) *' : 'Pincode (6 Digit) *'}
                className={`w-full px-3 py-2 text-xs sm:text-sm rounded-xl border bg-[#fafcfa] focus:bg-white focus:outline-none transition-colors font-mono tabular-nums ${
                  errors.pincode ? 'border-red-500' : 'border-[#d2ded6] focus:border-[#083c2e]'
                }`}
              />
              {errors.pincode && <p className="text-[10px] text-red-500 mt-0.5">{errors.pincode}</p>}
            </div>

            <div>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder={lang === 'hi' ? 'शहर / जिला (City) *' : 'City / District *'}
                className={`w-full px-3 py-2 text-xs sm:text-sm rounded-xl border bg-[#fafcfa] focus:bg-white focus:outline-none transition-colors ${
                  errors.city ? 'border-red-500' : 'border-[#d2ded6] focus:border-[#083c2e]'
                }`}
              />
              {errors.city && <p className="text-[10px] text-red-500 mt-0.5">{errors.city}</p>}
            </div>
          </div>
        </div>

        {/* Step 3: Payment Method Selector */}
        <div className="pt-1">
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setPaymentMethod('cod')}
              className={`p-2 rounded-xl border text-left transition-all ${
                paymentMethod === 'cod'
                  ? 'border-[#083c2e] bg-[#f0f7f3] text-[#083c2e] font-bold'
                  : 'border-[#dfe8e2] bg-[#fbfdfc] text-[#4d6658]'
              }`}
            >
              <div className="text-xs font-extrabold flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-[#0d5440]" />
                <span>कैश ऑन डिलीवरी</span>
              </div>
              <div className="text-[10px] text-[#657d71]">घर पर भुगतान करें</div>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('prepaid')}
              className={`p-2 rounded-xl border text-left transition-all ${
                paymentMethod === 'prepaid'
                  ? 'border-[#083c2e] bg-[#f0f7f3] text-[#083c2e] font-bold'
                  : 'border-[#dfe8e2] bg-[#fbfdfc] text-[#4d6658]'
              }`}
            >
              <div className="text-xs font-extrabold flex items-center justify-between">
                <span>ऑनलाइन UPI</span>
                <span className="text-[9px] bg-[#fef3c7] text-[#b45309] px-1 rounded font-bold">₹100 छूट</span>
              </div>
              <div className="text-[10px] text-[#657d71]">तुरंत ₹100 बचत</div>
            </button>
          </div>
        </div>

        {/* Price Lockup & Submit Button */}
        <div className="pt-2 space-y-2">
          <div className="flex items-center justify-between text-xs bg-[#f4f8f5] p-2.5 rounded-xl border border-[#dce7e0]">
            <span className="text-[#3b5447]">
              {lang === 'hi' ? 'कुल देय राशि (डिलीवरी पर):' : 'Total Amount (Pay on Delivery):'}
            </span>
            <span className="text-base font-black text-[#083c2e] tabular-nums">
              ₹{finalAmount.toLocaleString('en-IN')}
            </span>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 px-4 bg-[#083c2e] hover:bg-[#0c4e3c] text-white font-extrabold text-sm sm:text-base rounded-xl transition-all shadow-md active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer"
          >
            {isSubmitting ? (
              <span>{lang === 'hi' ? 'ऑर्डर दर्ज हो रहा है...' : 'Booking your order...'}</span>
            ) : (
              <>
                <ShieldCheck className="w-5 h-5 text-[#f59e0b]" />
                <span>
                  {lang === 'hi'
                    ? `अभी ऑर्डर बुक करें - ₹${finalAmount.toLocaleString('en-IN')} (COD)`
                    : `Confirm Cash on Delivery Order - ₹${finalAmount.toLocaleString('en-IN')}`}
                </span>
              </>
            )}
          </button>
        </div>

        {/* Phone Assist Note */}
        <div className="text-[11px] text-center text-[#557062] pt-1">
          <span>{lang === 'hi' ? 'फोन पर सहायता या पूछताछ के लिए:' : 'Need help over call:'} </span>
          <a href={CONTACT_INFO.telUrl} className="font-bold text-[#083c2e] hover:underline font-mono">
            {CONTACT_INFO.displayPhone}
          </a>
        </div>
      </form>
    </div>
  );
};
