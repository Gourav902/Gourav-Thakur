import React, { useState } from 'react';
import { Language } from '../types';
import { FAQS, CONTACT_INFO } from '../data/content';
import { HelpCircle, ChevronDown, PhoneCall, MessageCircle } from 'lucide-react';

interface FAQSectionProps {
  lang: Language;
}

export const FAQSection: React.FC<FAQSectionProps> = ({ lang }) => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIdx((prev) => (prev === idx ? null : idx));
  };

  return (
    <section id="faqs" className="py-14 sm:py-20 bg-white border-b border-[#e2ece5]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#eef6f2] text-[#0d5440] text-xs font-bold rounded-md tracking-wider uppercase mb-3">
            <HelpCircle className="w-3.5 h-3.5 text-[#0d5440]" />
            <span>{lang === 'hi' ? 'अक्सर पूछे जाने वाले सवाल' : 'Frequently Asked Questions'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#093226] tracking-tight text-balance">
            {lang === 'hi'
              ? 'शुगर केयर के बारे में आपके मन के सभी सवालों के जवाब'
              : 'Clear, Transparent Answers to Your Questions'}
          </h2>
          <div className="mt-4 flex flex-wrap items-center justify-center gap-3 text-sm text-[#355344]">
            <span>
              {lang === 'hi'
                ? 'यदि आपका कोई अन्य प्रश्न है, तो हमारी स्वास्थ्य टीम से संपर्क करें:'
                : 'Need more clarification? Reach out to our wellness team:'}
            </span>
            <div className="inline-flex items-center gap-2">
              <a
                href={CONTACT_INFO.telUrl}
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#083c2e] text-white rounded-lg font-bold text-xs hover:bg-[#0c4e3c] transition-colors"
              >
                <PhoneCall className="w-3.5 h-3.5 text-[#f59e0b]" />
                <span>{CONTACT_INFO.displayPhone}</span>
              </a>
              <a
                href={CONTACT_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#25d366] text-white rounded-lg font-bold text-xs hover:bg-[#1faa53] transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-4">
          {FAQS.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl border border-[#dce6df] overflow-hidden transition-all bg-[#fbfdfb]"
              >
                <button
                  type="button"
                  onClick={() => toggle(idx)}
                  className="w-full py-4 px-5 sm:px-6 text-left flex items-center justify-between gap-4 font-bold text-sm sm:text-base text-[#083c2e] hover:bg-[#f2f7f4] transition-colors"
                >
                  <span>{lang === 'hi' ? faq.questionHi : faq.questionEn}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-[#0d5440] shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-5 pt-1 text-xs sm:text-sm text-[#3b5447] leading-relaxed border-t border-[#e8f0eb] bg-white">
                    <p>{lang === 'hi' ? faq.answerHi : faq.answerEn}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
