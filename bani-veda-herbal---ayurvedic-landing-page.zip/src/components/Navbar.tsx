import React from 'react';
import { Language } from '../types';
import { CONTACT_INFO } from '../data/content';
import { ShoppingBag, Globe, PhoneCall, MessageCircle, FileSpreadsheet } from 'lucide-react';

interface NavbarProps {
  lang: Language;
  onToggleLang: () => void;
  onOpenOrder: () => void;
  onOpenSheets?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ lang, onToggleLang, onOpenOrder, onOpenSheets }) => {
  return (
    <>
      {/* Top Notification Announcement Bar */}
      <div className="bg-[#05261d] text-[#e2f1ea] text-xs py-2 px-3 sm:px-4 border-b border-[#0f4637]">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-[#f59e0b] tracking-wider uppercase">
              {lang === 'hi' ? 'विशेष ऑफर' : 'SPECIAL OFFER'}
            </span>
            <span>·</span>
            <span>
              {lang === 'hi'
                ? 'पूरे भारत में फ्री कैश ऑन डिलीवरी (COD) उपलब्ध'
                : 'Free Cash on Delivery (COD) across all India PIN codes'}
            </span>
          </div>
          <div className="flex items-center gap-3 sm:gap-4 text-[11px] text-[#b6d9cb]">
            <a
              href={CONTACT_INFO.telUrl}
              className="flex items-center gap-1.5 font-bold text-[#f59e0b] hover:text-white transition-colors bg-[#083c2e] px-2 py-0.5 rounded border border-[#135a47]"
              title="Click to Call"
            >
              <PhoneCall className="w-3 h-3 text-[#f59e0b]" />
              <span className="text-white hidden xs:inline">{lang === 'hi' ? 'कॉल:' : 'Call:'}</span>
              <span className="tabular-nums tracking-wide">{CONTACT_INFO.displayPhone}</span>
            </a>
            <a
              href={CONTACT_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-1 text-[#4ade80] hover:text-white transition-colors"
              title="Chat on WhatsApp"
            >
              <MessageCircle className="w-3 h-3 text-[#4ade80]" />
              <span>WhatsApp</span>
            </a>
            <span className="hidden md:inline">|</span>
            <span className="hidden md:inline">100% Shuddh Ayurvedic Proprietary Medicine</span>
          </div>
        </div>
      </div>

      {/* Top Navigation Bar: 3-Zone Contract */}
      <header className="sticky top-0 z-40 bg-[#ffffff]/95 backdrop-blur-md border-b border-[#e5ece7]">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 py-3.5">
          {/* Zone 1: Single text element wordmark */}
          <a href="#" className="flex items-center gap-2 text-[#083c2e] font-bold text-xl sm:text-2xl tracking-tight whitespace-nowrap shrink-0">
            <span className="w-2.5 h-2.5 rounded-full bg-[#10b981] inline-block"></span>
            <span>BANI VEDA</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-[#f3f8f5] text-[#0d5440] border border-[#d2e4db] tracking-wide">
              AYURVEDA
            </span>
          </a>

          {/* Zone 2: Single-line text navigation links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#2d4137]">
            <a href="#herbs" className="hover:text-[#083c2e] transition-colors whitespace-nowrap shrink-0">
              {lang === 'hi' ? '6 जड़ी-बूटियां' : '6 Key Herbs'}
            </a>
            <a href="#benefits" className="hover:text-[#083c2e] transition-colors whitespace-nowrap shrink-0">
              {lang === 'hi' ? 'आयुर्वेदिक लाभ' : 'Clinical Benefits'}
            </a>
            <a href="#calculator" className="hover:text-[#083c2e] transition-colors whitespace-nowrap shrink-0">
              {lang === 'hi' ? 'शुगर चेक करें' : 'Dosage Check'}
            </a>
            <a href="#timeline" className="hover:text-[#083c2e] transition-colors whitespace-nowrap shrink-0">
              {lang === 'hi' ? 'परिणाम समय-सीमा' : 'Timeline'}
            </a>
            <a href="#bundles" className="hover:text-[#083c2e] transition-colors whitespace-nowrap shrink-0">
              {lang === 'hi' ? 'पैकेज व मूल्य' : 'Pricing Packs'}
            </a>
            <a href="#faqs" className="hover:text-[#083c2e] transition-colors whitespace-nowrap shrink-0">
              {lang === 'hi' ? 'प्रश्नोत्तरी' : 'FAQs'}
            </a>
          </nav>

          {/* Zone 3: Contact button, Language toggle & Primary Action */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {onOpenSheets && (
              <button
                type="button"
                onClick={onOpenSheets}
                className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-[#0d5440] bg-[#eef7f2] hover:bg-[#dff0e6] border border-[#c2ded0] rounded-lg transition-colors cursor-pointer"
                title="Google Sheets Sync"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-[#10b981]" />
                <span>Google Sheets</span>
              </button>
            )}

            <a
              href={CONTACT_INFO.telUrl}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-bold text-[#083c2e] bg-[#ecfdf5] border border-[#a7f3d0] hover:bg-[#d1fae5] rounded-lg transition-colors whitespace-nowrap"
              title="Call Helpline"
            >
              <PhoneCall className="w-3.5 h-3.5 text-[#059669]" />
              <span className="hidden sm:inline">{CONTACT_INFO.displayPhone}</span>
              <span className="sm:hidden">{lang === 'hi' ? 'कॉल करें' : 'Call'}</span>
            </a>

            <button
              onClick={onToggleLang}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-[#1c382e] bg-[#edf4f0] hover:bg-[#dfeee5] rounded-md transition-colors whitespace-nowrap"
              title="Change Language"
            >
              <Globe className="w-3.5 h-3.5 text-[#0d5440]" />
              <span>{lang === 'hi' ? 'English' : 'हिंदी'}</span>
            </button>

            <button
              onClick={onOpenOrder}
              className="flex items-center gap-2 px-3.5 sm:px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-[#083c2e] hover:bg-[#0d5440] shadow-sm rounded-lg transition-all active:scale-[0.98] whitespace-nowrap shrink-0"
            >
              <ShoppingBag className="w-4 h-4 text-[#f59e0b]" />
              <span>{lang === 'hi' ? 'ऑर्डर करें (COD)' : 'Order Now (COD)'}</span>
            </button>
          </div>
        </div>
      </header>
    </>
  );
};
