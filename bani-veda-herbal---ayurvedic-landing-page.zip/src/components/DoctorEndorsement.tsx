import React from 'react';
import { Language } from '../types';
import { Award, CheckCircle2, ShieldCheck } from 'lucide-react';

interface DoctorEndorsementProps {
  lang: Language;
}

export const DoctorEndorsement: React.FC<DoctorEndorsementProps> = ({ lang }) => {
  return (
    <section className="py-14 sm:py-20 bg-white border-b border-[#e2ece5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        <div className="bg-[#f7faf8] rounded-3xl border border-[#dce6df] p-6 sm:p-10 lg:p-12 relative overflow-hidden">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left Doctor Badge & Quote */}
            <div className="lg:col-span-8 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#e8f2ec] text-[#083c2e] text-xs font-bold rounded-md tracking-wider uppercase">
                <Award className="w-3.5 h-3.5 text-[#0d5440]" />
                <span>{lang === 'hi' ? 'वरिष्ठ आयुर्वेदाचार्य की अनुशंसा' : 'Ayurvedic Practitioner Endorsement'}</span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#083c2e] leading-snug">
                {lang === 'hi'
                  ? '"चरक संहिता के अनुसार, प्रमेह (शुगर) को नियंत्रित करने के लिए तिक्त व कषाय रसों का ऐसा संतुलन आवश्यक है जो पैंक्रियाज को नुकसान न पहुंचाए।"'
                  : '"In classical Ayurveda, glycemic balance requires a precise harmony of Tikta and Kashaya herbs that protect pancreatic tissues."'}
              </h2>

              <p className="text-sm sm:text-base text-[#385144] leading-relaxed">
                {lang === 'hi'
                  ? 'शुगर केयर (Sugar Care 6 in 1) की सबसे बड़ी खूबी यह है कि इसमें केवल कच्चा चूर्ण नहीं, बल्कि मानकीकृत जड़ी-बूटियों का सत्व है। गुड़मार की जिम्नेमिक शक्ति, जामुन की जाम्बोलीन और करेला का प्लांट-इंसुलिन जब एक साथ मिलते हैं, तो यह सीधे रक्त में ग्लूकोज के अति-स्राव को रोकते हैं। मैं अपने अनेक मरीजों में इसके नियमित सेवन से सकारात्मक सुधार देख चुका हूँ।'
                  : 'Sugar Care stands out because it utilizes standardized plant extracts rather than raw fibrous powders. The synergistic action of Gymnemic acid from Gurmar, Jamboline from Jamun, and Charantin from Karela provides comprehensive support without exhausting the body.'}
              </p>

              <div className="pt-4 border-t border-[#d8e4dc] flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h4 className="text-base font-extrabold text-[#083c2e]">
                    वैद्यराज डॉ. राजेश्वर शर्मा (Dr. R. Sharma)
                  </h4>
                  <p className="text-xs text-[#526a5e]">
                    B.A.M.S., M.D. (Ayurveda) · 24+ {lang === 'hi' ? 'वर्षों का क्लिनिकल अनुभव' : 'Years Clinical Practice'}
                  </p>
                </div>

                <div className="flex items-center gap-3 text-xs text-[#1f3b2d]">
                  <span className="flex items-center gap-1 font-semibold">
                    <CheckCircle2 className="w-4 h-4 text-[#10b981]" />
                    {lang === 'hi' ? 'सत्यापित आयुष मानक' : 'Verified AYUSH Protocol'}
                  </span>
                  <span>·</span>
                  <span className="flex items-center gap-1 font-semibold">
                    <ShieldCheck className="w-4 h-4 text-[#10b981]" />
                    {lang === 'hi' ? '100% केमिकल-मुक्त' : 'Zero Steroids/Chemicals'}
                  </span>
                </div>
              </div>

            </div>

            {/* Right Side Credentials Card */}
            <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-[#d6e2db] shadow-xs space-y-4 text-center">
              <div className="w-20 h-20 rounded-full bg-[#eef6f2] border-2 border-[#10b981]/30 mx-auto flex items-center justify-center text-[#083c2e]">
                <ShieldCheck className="w-10 h-10 text-[#0d5440]" />
              </div>

              <div>
                <div className="text-xs font-bold uppercase text-[#b45309] tracking-wider">
                  Quality Assurance
                </div>
                <div className="text-lg font-extrabold text-[#083c2e] mt-1">
                  GMP & ISO 9001 Certified
                </div>
                <p className="text-xs text-[#597365] mt-1.5 leading-relaxed">
                  {lang === 'hi'
                    ? 'प्रत्येक बैच भारी धातुओं (लेड, मर्करी) और रसायनों की कठोर प्रयोगशाला जांच के बाद ही पैक किया जाता है।'
                    : 'Each manufacturing batch undergoes rigorous heavy-metal and microbiological testing before bottling.'}
                </p>
              </div>

              <div className="pt-2 text-[11px] text-[#486355] border-t border-[#e5eee8] flex justify-around">
                <span>✓ Non-Habit Forming</span>
                <span>✓ 100% Herbal</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
