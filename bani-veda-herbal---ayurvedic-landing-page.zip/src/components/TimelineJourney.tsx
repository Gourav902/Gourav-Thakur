import React from 'react';
import { Language } from '../types';
import { Calendar, CheckCircle2, TrendingDown, BatteryCharging, ShieldAlert } from 'lucide-react';

interface TimelineJourneyProps {
  lang: Language;
}

export const TimelineJourney: React.FC<TimelineJourneyProps> = ({ lang }) => {
  return (
    <section id="timeline" className="py-14 sm:py-20 bg-white border-b border-[#e5ebe6]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#eef6f2] text-[#0d5440] text-xs font-bold rounded-md tracking-wider uppercase mb-3">
            <Calendar className="w-3.5 h-3.5 text-[#0d5440]" />
            <span>{lang === 'hi' ? 'आयुर्वेदिक सुधार समय-चक्र' : 'Transformation Trajectory'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#093226] tracking-tight text-balance">
            {lang === 'hi'
              ? 'शुगर केयर शुरू करने के 90 दिनों में क्या परिवर्तन आता है?'
              : 'What to Expect: Your 90-Day Metabolic Restoration Roadmap'}
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#4c6558]">
            {lang === 'hi'
              ? 'आयुर्वेदिक औषधियां शरीर के आंतरिक अंगों के साथ मिलकर काम करती हैं। यहाँ देखें सप्ताह दर सप्ताह आपका शरीर कैसे पुनः संतुलित होता है।'
              : 'Ayurvedic formulations work adaptogenically. Here is the realistic week-by-week physiological trajectory experienced by over 45,000 patients.'}
          </p>
        </div>

        {/* 3 Step Timeline Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
          
          {/* Phase 1 */}
          <div className="bg-[#f9fbf9] rounded-3xl p-6 sm:p-8 border border-[#dce6df] relative flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-extrabold px-3 py-1 bg-[#fef3c7] text-[#b45309] rounded-lg uppercase tracking-wider">
                  Phase 1 · Days 1 - 15
                </span>
                <BatteryCharging className="w-5 h-5 text-[#f59e0b]" />
              </div>
              <h3 className="text-xl font-bold text-[#083c2e] mb-3">
                {lang === 'hi' ? 'मीठे की तलब में कमी व सुस्ती से राहत' : 'Craving Reset & Energy Surge'}
              </h3>
              <p className="text-xs sm:text-sm text-[#4c6558] leading-relaxed mb-4">
                {lang === 'hi'
                  ? 'गुड़मार जीभ के स्वीट बड्स को शांत करता है। दोपहर में खाना खाने के बाद होने वाला भारीपन और अचानक थकान खत्म होने लगती है।'
                  : 'Gymnemic acid dulls tongue sweetness perception. Post-meal carbohydrate lethargy fades, and digestion feels light.'}
              </p>
            </div>
            
            <div className="pt-4 border-t border-[#e2ede6] space-y-2 text-xs text-[#2a4537]">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#10b981] shrink-0" />
                <span>{lang === 'hi' ? 'खाने के बाद की सुस्ती में 60% कमी' : 'Reduced post-lunch drowsiness'}</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#10b981] shrink-0" />
                <span>{lang === 'hi' ? 'गले का बार-बार सूखना कम' : 'Normal saliva and throat moisture'}</span>
              </div>
            </div>
          </div>

          {/* Phase 2 */}
          <div className="bg-[#f0f7f3] rounded-3xl p-6 sm:p-8 border-2 border-[#0e6047] relative flex flex-col justify-between shadow-md">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-extrabold px-3 py-1 bg-[#083c2e] text-white rounded-lg uppercase tracking-wider">
                  Phase 2 · Days 16 - 45
                </span>
                <TrendingDown className="w-5 h-5 text-[#10b981]" />
              </div>
              <h3 className="text-xl font-bold text-[#083c2e] mb-3">
                {lang === 'hi' ? 'फास्टिंग व पीपी शुगर में ठोस गिरावट' : 'Fasting Glucose Stabilization'}
              </h3>
              <p className="text-xs sm:text-sm text-[#3b5548] leading-relaxed mb-4">
                {lang === 'hi'
                  ? 'करेला और जामुन रक्त में ग्लूकोज के अवशोषण को नियंत्रित करते हैं। ग्लूकोमीटर की रीडिंग में निरंतर स्थिरता आने लगती है और रात में पेशाब पर नियंत्रण होता है।'
                  : 'Polypeptide-P and Jamboline optimize insulin receptor sensitivity. Morning fasting readings trend downward and night urination normalizes.'}
              </p>
            </div>

            <div className="pt-4 border-t border-[#d1e5db] space-y-2 text-xs text-[#1e392d] font-semibold">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#083c2e] shrink-0" />
                <span>{lang === 'hi' ? 'फास्टिंग स्तर में 30-50 mg/dL तक सुधार' : '30-50 mg/dL average fasting drop'}</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#083c2e] shrink-0" />
                <span>{lang === 'hi' ? 'पैरों की नसों में जलन व सुन्नता शांत' : 'Calmed foot tingling and cramps'}</span>
              </div>
            </div>
          </div>

          {/* Phase 3 */}
          <div className="bg-[#f9fbf9] rounded-3xl p-6 sm:p-8 border border-[#dce6df] relative flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-extrabold px-3 py-1 bg-[#d1fae5] text-[#065f46] rounded-lg uppercase tracking-wider">
                  Phase 3 · Days 46 - 90
                </span>
                <ShieldAlert className="w-5 h-5 text-[#059669]" />
              </div>
              <h3 className="text-xl font-bold text-[#083c2e] mb-3">
                {lang === 'hi' ? 'HbA1c संतुलन व पैंक्रियाज कायाकल्प' : 'HbA1c Rebalance & Beta-Cell Rejuvenation'}
              </h3>
              <p className="text-xs sm:text-sm text-[#4c6558] leading-relaxed mb-4">
                {lang === 'hi'
                  ? '3 माह का पूर्ण कोर्स पैंक्रियाज की बीटा-सेल्स को प्राकृतिक मजबूती देता है। तीन महीने की HbA1c रिपोर्ट में उल्लेखनीय गिरावट दर्ज होती है।'
                  : 'Sustained rasayana action provides lasting beta-cell support, preventing long-term diabetic vascular complications.'}
              </p>
            </div>

            <div className="pt-4 border-t border-[#e2ede6] space-y-2 text-xs text-[#2a4537]">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#10b981] shrink-0" />
                <span>{lang === 'hi' ? 'HbA1c स्तर 7 से नीचे लाने में सहायक' : 'Supports bringing HbA1c below 7.0'}</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#10b981] shrink-0" />
                <span>{lang === 'hi' ? 'दीर्घकालिक प्राकृतिक रोग प्रतिरोधक क्षमता' : 'Long-term metabolic resilience'}</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
