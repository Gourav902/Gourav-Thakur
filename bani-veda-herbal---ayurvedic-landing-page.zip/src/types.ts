export type Language = 'hi' | 'en';

export interface HerbInfo {
  id: string;
  nameHi: string;
  nameEn: string;
  botanicalName: string;
  keyActive: string;
  ayurvedicAction: string;
  benefit: string;
  tag: string;
  colorScheme: {
    bg: string;
    border: string;
    badge: string;
    text: string;
  };
}

export interface PricingBundle {
  id: string;
  bottles: number;
  capsuleCount: number;
  durationMonths: number;
  titleHi: string;
  titleEn: string;
  badge?: string;
  mrp: number;
  price: number;
  savings: number;
  bonusFeatures: string[];
  recommendedFor: string;
  popular?: boolean;
}

export interface Testimonial {
  id: string;
  name: string;
  age: number;
  city: string;
  beforeFasting: number;
  afterFasting: number;
  beforeHba1c: number;
  afterHba1c: number;
  timeframe: string;
  quoteHi: string;
  quoteEn: string;
  verifiedPurchase: boolean;
  avatarLetter: string;
}

export interface OrderDetails {
  bundleId: string;
  fullName: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  paymentMethod: 'cod' | 'prepaid';
}
