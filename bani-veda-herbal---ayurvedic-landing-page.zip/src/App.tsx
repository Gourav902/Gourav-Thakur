/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Language } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { SugarCheckerQuiz } from './components/SugarCheckerQuiz';
import { HerbsDeepDive } from './components/HerbsDeepDive';
import { ProductBenefits } from './components/ProductBenefits';
import { TimelineJourney } from './components/TimelineJourney';
import { PricingBundles } from './components/PricingBundles';
import { DoctorEndorsement } from './components/DoctorEndorsement';
import { Testimonials } from './components/Testimonials';
import { FAQSection } from './components/FAQSection';
import { Footer } from './components/Footer';
import { StickyBottomBar } from './components/StickyBottomBar';
import { OrderModal } from './components/OrderModal';
import { FloatingContact } from './components/FloatingContact';
import { SupabaseAdminModal } from './components/SupabaseAdminModal';
import { GoogleSheetsModal } from './components/GoogleSheetsModal';

export default function App() {
  const [lang, setLang] = useState<Language>('hi');
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [isDbAdminOpen, setIsDbAdminOpen] = useState(false);
  const [isSheetsModalOpen, setIsSheetsModalOpen] = useState(false);
  const [preselectedBundle, setPreselectedBundle] = useState<string>('double');

  const handleToggleLang = () => {
    setLang((prev) => (prev === 'hi' ? 'en' : 'hi'));
  };

  const handleOpenOrder = (bundleId: string = 'single') => {
    const formEl = document.getElementById('quick-order-form');
    if (formEl) {
      formEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      const firstInput = formEl.querySelector('input');
      if (firstInput) {
        setTimeout(() => (firstInput as HTMLInputElement).focus(), 400);
      }
    } else {
      setPreselectedBundle(bundleId);
      setIsOrderModalOpen(true);
    }
  };

  const handleScrollToQuiz = () => {
    const el = document.getElementById('calculator');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f8faf8] text-[#1e2922] selection:bg-[#083c2e] selection:text-white">
      {/* Top Header & Navigation */}
      <Navbar
        lang={lang}
        onToggleLang={handleToggleLang}
        onOpenOrder={() => handleOpenOrder('single')}
        onOpenSheets={() => setIsSheetsModalOpen(true)}
      />

      {/* Main Page Sections */}
      <main className="flex-1">
        {/* High-Impact Hero with Uploaded Sugar Care Bottle Showcase */}
        <Hero
          lang={lang}
          onOpenOrder={() => handleOpenOrder('single')}
          onScrollToQuiz={handleScrollToQuiz}
        />

        {/* Interactive Blood Sugar Assessment & Dosage Calculator */}
        <SugarCheckerQuiz
          lang={lang}
          onSelectBundleAndOrder={(bundleId) => handleOpenOrder(bundleId)}
        />

        {/* 6 Powerful Herbs Botanical Deep Dive */}
        <HerbsDeepDive lang={lang} />

        {/* Biological Mechanism & Head-to-Head Comparison */}
        <ProductBenefits lang={lang} />

        {/* 90-Day Metabolic Transformation Trajectory */}
        <TimelineJourney lang={lang} />

        {/* Value Packages & Pricing with Doorstep COD */}
        <PricingBundles
          lang={lang}
          onSelectBundle={(bundleId) => handleOpenOrder(bundleId)}
        />

        {/* Clinical Ayurvedic Doctor Endorsement */}
        <DoctorEndorsement lang={lang} />

        {/* Verified Patient HbA1c & Fasting Testimonials */}
        <Testimonials lang={lang} />

        {/* Frequently Asked Questions */}
        <FAQSection lang={lang} />
      </main>

      {/* Quiet Compliant Footer */}
      <Footer
        lang={lang}
        onOpenDbAdmin={() => setIsDbAdminOpen(true)}
        onOpenSheets={() => setIsSheetsModalOpen(true)}
      />

      {/* Non-intrusive Sticky Bottom Bar (Mobile/Desktop) */}
      <StickyBottomBar
        lang={lang}
        onOpenOrder={() => handleOpenOrder('single')}
      />

      {/* Floating 24x7 Call & WhatsApp Button (9711293726) */}
      <FloatingContact lang={lang} />

      {/* Fast Cash-On-Delivery Checkout Modal */}
      <OrderModal
        isOpen={isOrderModalOpen}
        onClose={() => setIsOrderModalOpen(false)}
        lang={lang}
        preselectedBundleId={preselectedBundle}
      />

      {/* Supabase Bookings & Connection Manager Modal */}
      <SupabaseAdminModal
        isOpen={isDbAdminOpen}
        onClose={() => setIsDbAdminOpen(false)}
      />

      {/* Google Sheets Sync & Manager Modal */}
      <GoogleSheetsModal
        isOpen={isSheetsModalOpen}
        onClose={() => setIsSheetsModalOpen(false)}
      />
    </div>
  );
}
