import { getGoogleAccessToken, signInWithGoogleAuth } from '../lib/firebase';
import { BookingPayload } from './bookingService';

export interface SheetConfig {
  spreadsheetId: string;
  spreadsheetUrl: string;
  spreadsheetTitle: string;
}

const STORAGE_KEY_SHEET_ID = 'bv_google_sheet_id';
const STORAGE_KEY_SHEET_URL = 'bv_google_sheet_url';
const STORAGE_KEY_SHEET_TITLE = 'bv_google_sheet_title';

export const getSavedSheetConfig = (): SheetConfig | null => {
  try {
    const id = localStorage.getItem(STORAGE_KEY_SHEET_ID);
    const url = localStorage.getItem(STORAGE_KEY_SHEET_URL);
    const title = localStorage.getItem(STORAGE_KEY_SHEET_TITLE);
    if (id && url) {
      return {
        spreadsheetId: id,
        spreadsheetUrl: url,
        spreadsheetTitle: title || 'Bani Ayurveda - Orders',
      };
    }
  } catch (_e) {}
  return null;
};

export const saveSheetConfig = (config: SheetConfig) => {
  try {
    localStorage.setItem(STORAGE_KEY_SHEET_ID, config.spreadsheetId);
    localStorage.setItem(STORAGE_KEY_SHEET_URL, config.spreadsheetUrl);
    localStorage.setItem(STORAGE_KEY_SHEET_TITLE, config.spreadsheetTitle);
  } catch (_e) {}
};

/**
 * Creates or retrieves the dedicated Google Spreadsheet for customer orders
 */
export async function getOrCreateOrdersSheet(customTitle = 'Bani Ayurveda - Customer Orders'): Promise<SheetConfig> {
  let token = getGoogleAccessToken();
  if (!token) {
    const res = await signInWithGoogleAuth();
    token = res.accessToken;
  }

  // 1. Check if user already has this spreadsheet on Google Drive
  try {
    const query = encodeURIComponent(`name = '${customTitle}' and mimeType = 'application/vnd.google-apps.spreadsheet' and trashed = false`);
    const searchRes = await fetch(`https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,webViewLink)`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (searchRes.ok) {
      const searchData = await searchRes.json();
      if (searchData.files && searchData.files.length > 0) {
        const file = searchData.files[0];
        const config: SheetConfig = {
          spreadsheetId: file.id,
          spreadsheetUrl: file.webViewLink || `https://docs.google.com/spreadsheets/d/${file.id}/edit`,
          spreadsheetTitle: file.name,
        };
        saveSheetConfig(config);
        return config;
      }
    }
  } catch (err) {
    console.warn('Drive search error, falling back to creating new sheet:', err);
  }

  // 2. Create a new Google Spreadsheet with headers
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: customTitle,
      },
      sheets: [
        {
          properties: {
            title: 'Orders',
            gridProperties: {
              frozenRowCount: 1,
            },
          },
          data: [
            {
              startRow: 0,
              startColumn: 0,
              rowData: [
                {
                  values: [
                    { userEnteredValue: { stringValue: 'Order ID' } },
                    { userEnteredValue: { stringValue: 'Date & Time' } },
                    { userEnteredValue: { stringValue: 'Customer Name' } },
                    { userEnteredValue: { stringValue: 'Mobile Number' } },
                    { userEnteredValue: { stringValue: 'Delivery Address' } },
                    { userEnteredValue: { stringValue: 'City' } },
                    { userEnteredValue: { stringValue: 'Pincode' } },
                    { userEnteredValue: { stringValue: 'Selected Pack' } },
                    { userEnteredValue: { stringValue: 'Bottles' } },
                    { userEnteredValue: { stringValue: 'Price (₹)' } },
                    { userEnteredValue: { stringValue: 'Payment Mode' } },
                    { userEnteredValue: { stringValue: 'Status' } },
                  ],
                },
              ],
            },
          ],
        },
      ],
    }),
  });

  if (!createRes.ok) {
    const errData = await createRes.json().catch(() => ({}));
    throw new Error(errData.error?.message || 'Failed to create Google Spreadsheet');
  }

  const sheetData = await createRes.json();
  const config: SheetConfig = {
    spreadsheetId: sheetData.spreadsheetId,
    spreadsheetUrl: sheetData.spreadsheetUrl,
    spreadsheetTitle: customTitle,
  };

  saveSheetConfig(config);
  return config;
}

/**
 * Appends a booking record as a new row in the connected Google Sheet
 */
export async function appendOrderToGoogleSheet(
  spreadsheetId: string,
  order: BookingPayload & { createdAt?: string; status?: string }
): Promise<boolean> {
  const token = getGoogleAccessToken();
  if (!token) return false;

  const nowFormatted = order.createdAt
    ? new Date(order.createdAt).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })
    : new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

  const rowValues = [
    order.orderId,
    nowFormatted,
    order.fullName,
    `'${order.phone}`, // leading quote prevents scientific notation for numbers
    order.address,
    order.city,
    `'${order.pincode}`,
    order.bundleTitle || order.bundleId,
    order.bottles || 1,
    order.price,
    (order.paymentMethod || 'COD').toUpperCase(),
    order.status || 'CONFIRMED',
  ];

  try {
    // Detect sheet name first (either "Orders" or first sheet)
    const metaRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties.title`,
      { headers: { Authorization: `Bearer ${token}` } }
    );

    let sheetName = 'Orders';
    if (metaRes.ok) {
      const meta = await metaRes.json();
      sheetName = meta.sheets?.[0]?.properties?.title || 'Orders';
    }

    const appendRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetName)}!A:L:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          values: [rowValues],
        }),
      }
    );

    return appendRes.ok;
  } catch (err) {
    console.error('Error appending order to Google Sheet:', err);
    return false;
  }
}

/**
 * Syncs an array of orders to the Google Sheet in batch
 */
export async function syncBatchOrdersToGoogleSheet(
  spreadsheetId: string,
  orders: any[]
): Promise<{ added: number; error?: string }> {
  const token = getGoogleAccessToken();
  if (!token) {
    throw new Error('Google authentication required');
  }

  if (!orders || orders.length === 0) {
    return { added: 0 };
  }

  // Get sheet name
  let sheetName = 'Orders';
  try {
    const metaRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties.title`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    if (metaRes.ok) {
      const meta = await metaRes.json();
      sheetName = meta.sheets?.[0]?.properties?.title || 'Orders';
    }
  } catch (_e) {}

  const rows = orders.map((o) => [
    o.order_id || o.orderId,
    o.created_at ? new Date(o.created_at).toLocaleString('en-IN') : new Date().toLocaleString('en-IN'),
    o.full_name || o.fullName,
    `'${o.phone}`,
    o.address,
    o.city,
    `'${o.pincode}`,
    o.bundle_title || o.bundleTitle || 'Bani Ayurveda 6-IN-1',
    o.bottles || 1,
    o.price,
    (o.payment_method || o.paymentMethod || 'COD').toUpperCase(),
    o.status || 'CONFIRMED',
  ]);

  const appendRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetName)}!A:L:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ values: rows }),
    }
  );

  if (!appendRes.ok) {
    const err = await appendRes.json().catch(() => ({}));
    throw new Error(err.error?.message || 'Failed to sync orders to Google Sheet');
  }

  return { added: rows.length };
}
