import { createClient } from '@supabase/supabase-js';
import { getSavedSheetConfig, appendOrderToGoogleSheet } from './googleSheetsService';
import { getGoogleAccessToken } from '../lib/firebase';

const SUPABASE_PROJECT_ID = 'mvmpfjkawcgmjzsabuwz';
export const SUPABASE_URL =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL) ||
  `https://${SUPABASE_PROJECT_ID}.supabase.co`;

export const SUPABASE_KEY =
  (typeof import.meta !== 'undefined' &&
    (import.meta.env?.VITE_SUPABASE_ANON_KEY || import.meta.env?.VITE_SUPABASE_API_KEY)) ||
  'sb_secret_77YmRmjiONgJC1h3a5S3cg_4RBAHBr7';

// Client-side Supabase instance for direct storage on Netlify / static hosts
export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: {
    persistSession: false,
    autoRefreshToken: false,
  },
});

export interface BookingPayload {
  orderId: string;
  fullName: string;
  phone: string;
  address: string;
  city: string;
  state?: string;
  pincode: string;
  bundleId: string;
  bundleTitle?: string;
  bottles?: number;
  price: number;
  paymentMethod: string;
}

export interface BookingResult {
  success: boolean;
  orderId: string;
  savedInSupabase: boolean;
  message?: string;
}

/**
 * Universal booking saver that works on both:
 * 1. Static JAMstack deployments (Netlify, Vercel, GitHub Pages) via direct Supabase REST client
 * 2. Full-stack server deployments (Node/Express, Cloud Run) via /api/bookings proxy
 */
export async function submitBooking(payload: BookingPayload): Promise<BookingResult> {
  // First attempt: Server-side proxy if running in full-stack mode
  try {
    const response = await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (response.ok) {
      const data = await response.json();
      const sheetCfg = getSavedSheetConfig();
      if (sheetCfg && getGoogleAccessToken()) {
        appendOrderToGoogleSheet(sheetCfg.spreadsheetId, payload).catch((e) =>
          console.warn('Google Sheet auto-append note:', e)
        );
      }
      return {
        success: true,
        orderId: data.orderId || payload.orderId,
        savedInSupabase: data.savedInSupabase !== false,
      };
    }
  } catch (_err) {
    // Proxy not available (e.g., static hosting on Netlify) - fallback to direct Supabase client below
  }

  // Second attempt: Direct Supabase client insertion (Ideal for Netlify static site)
  try {
    const { data: _data, error } = await supabase
      .from('bookings')
      .insert([
        {
          order_id: payload.orderId,
          full_name: payload.fullName,
          phone: payload.phone,
          address: payload.address,
          city: payload.city,
          state: payload.state || '',
          pincode: payload.pincode,
          bundle_id: payload.bundleId,
          bundle_title: payload.bundleTitle || '',
          bottles: payload.bottles || 1,
          price: payload.price,
          payment_method: payload.paymentMethod || 'cod',
          status: 'confirmed',
        },
      ])
      .select();

    if (error) {
      console.warn('Supabase direct insert status:', error.message);
      // Backup to browser storage on static hosting so record is never lost
      try {
        const existing = JSON.parse(localStorage.getItem('bv_local_bookings') || '[]');
        existing.unshift({
          ...payload,
          status: 'confirmed',
          created_at: new Date().toISOString(),
          saved_in_supabase: false,
        });
        localStorage.setItem('bv_local_bookings', JSON.stringify(existing));
      } catch (_e) {}

      return {
        success: true,
        orderId: payload.orderId,
        savedInSupabase: false,
        message: error.message,
      };
    }

    // Successfully saved directly in Supabase
    const sheetCfg = getSavedSheetConfig();
    if (sheetCfg && getGoogleAccessToken()) {
      appendOrderToGoogleSheet(sheetCfg.spreadsheetId, payload).catch((e) =>
        console.warn('Google Sheet auto-append note:', e)
      );
    }

    return {
      success: true,
      orderId: payload.orderId,
      savedInSupabase: true,
    };
  } catch (err: any) {
    console.error('Direct Supabase error:', err);
    return {
      success: true,
      orderId: payload.orderId,
      savedInSupabase: false,
      message: err.message,
    };
  }
}

/**
 * Check Supabase database health across Netlify or full-stack environments
 */
export async function checkDatabaseHealth() {
  // Try proxy first
  try {
    const res = await fetch('/api/supabase-status');
    if (res.ok) {
      return await res.json();
    }
  } catch (_e) {}

  // Fallback to direct client check (Netlify)
  try {
    const { data: _data, error } = await supabase.from('bookings').select('id').limit(1);
    if (error) {
      if (error.code === 'PGRST205') {
        return {
          connected: true,
          projectId: SUPABASE_PROJECT_ID,
          url: SUPABASE_URL,
          tableExists: false,
          message: "Connected to Supabase. The 'bookings' table is awaiting SQL setup.",
        };
      }
      return {
        connected: false,
        projectId: SUPABASE_PROJECT_ID,
        url: SUPABASE_URL,
        tableExists: false,
        error: error.message,
      };
    }

    return {
      connected: true,
      projectId: SUPABASE_PROJECT_ID,
      url: SUPABASE_URL,
      tableExists: true,
      message: "Connected to Supabase 'bookings' table successfully!",
    };
  } catch (err: any) {
    return {
      connected: false,
      projectId: SUPABASE_PROJECT_ID,
      url: SUPABASE_URL,
      tableExists: false,
      error: err.message,
    };
  }
}

/**
 * Fetch all stored bookings across Netlify or full-stack environments
 */
export async function getAllBookings() {
  // Try proxy first
  try {
    const res = await fetch('/api/bookings');
    if (res.ok) {
      const data = await res.json();
      if (data?.bookings?.length) return data.bookings;
    }
  } catch (_e) {}

  // Fallback: direct Supabase query
  try {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data && data.length > 0) {
      return data;
    }
  } catch (_e) {}

  // Fallback: local storage
  try {
    return JSON.parse(localStorage.getItem('bv_local_bookings') || '[]');
  } catch (_e) {
    return [];
  }
}
